<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/header.php');

// Fetch Fee
$price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='AyushmanCard_Fee'"));
$fee = $price['price'];
$resdata = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['aadhaar']) && !empty($_POST['state_code'])) {
    $aadhaar = trim($_POST['aadhaar']);
    $state_code = trim($_POST['state_code']);
    $appliedby = $udata['phone'];
    $debit_fee = $udata['balance'] - $fee;

    if ($udata['balance'] >= $fee) {
        $api_zone = "API_KEY_PASTE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )
        $url = "http://kycapizone.in/api/v2/aayushman/aayushamn.php?api_key=$api_zone&aadhaar_no=$aadhaar&state_code=$state_code";

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => 'GET',
        ));
        $response = curl_exec($curl);
        curl_close($curl);

        $apiResult = json_decode($response, true);

        if ($apiResult && $apiResult['success'] === true && $apiResult['response_code'] === '200') {
            $resdata = $apiResult['result'];

            // Deduct Wallet
            mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$appliedby'");
            mysqli_query($ahk_conn, "INSERT INTO wallethistory(userid, amount, balance, purpose, status, type) VALUES ('$appliedby', '$fee', '$debit_fee', 'Ayushman Card Check', '1', 'Debit')");
        } else {
            echo "<script>Swal.fire('Failed', 'API Error: " . htmlspecialchars($apiResult['response_message'] ?? 'Unknown error') . "', 'error');</script>";
        }
    } else {
        echo "<script>Swal.fire('Low Balance', 'Please recharge your wallet!', 'warning');</script>";
    }
}
?>


<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
    <div class="row">
      <!-- Left Panel -->
      <div class="col-md-4">
        <form method="POST" class="card p-3 shadow">
          <h5 class="mb-3 text-danger">Ayushman Card Verification</h5>
          <div class="form-group mb-2">
            <label>Aadhaar Number</label>
            <input type="text" name="aadhaar" maxlength="12" minlength="12" required class="form-control" placeholder="Enter 12-digit Aadhaar">
          </div>
          <div class="form-group mb-2">
            <label>Select State</label>
            <select name="state_code" class="form-control" required id="state_code">
              <option value="">-- Select State --</option>
            </select>
          </div>
          <div class="form-group mb-3">
            <label>Fee</label>
            <input type="text" class="form-control" value="₹ <?= $fee ?>" readonly>
          </div>
          <button type="submit" class="btn btn-success w-100"><i class="fa fa-search"></i> Submit</button>
        </form>
      </div>

      <!-- Right Panel -->
      <?php if (!empty($resdata)): ?>
      <div class="col-md-8">
        <div class="card p-3 shadow">
          <h5>✅ Ayushman Record Found</h5>
          <table class="table table-bordered table-striped">
            <tr><th>Aadhaar No</th><td><?= htmlspecialchars($resdata['aadhaar']) ?></td></tr>
            <tr><th>Card Number</th><td><?= htmlspecialchars($resdata['card_no']) ?></td></tr>
            <tr>
              <th>Card Image</th>
              <td>
                <?php
                  $imgData = $resdata['card_file'];
                  $imgName = 'Ayushman_' . $resdata['aadhaar'] . '.png';
                  if (strpos($imgData, 'base64,') !== false) {
                      $base64 = explode('base64,', $imgData)[1];
                      $path = "./../uploads/ayushman_cards/$imgName";
                      file_put_contents($path, base64_decode($base64));
                      echo "<img src='$path' style='height:150px;border:1px solid #aaa;'><br>";
                      echo "<a href='$path' download='$imgName' class='btn btn-primary btn-sm mt-2'>Download Card</a>";
                  } else {
                      echo "Invalid card format.";
                  }
                ?>
              </td>
            </tr>
          </table>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include('footer.php'); ?>

<!-- State Dropdown JS -->
<script>
  const states = [
    { "code": "35", "name": "ANDAMAN AND NICOBAR ISLANDS" },
    { "code": "28", "name": "ANDHRA PRADESH" },
    { "code": "12", "name": "ARUNACHAL PRADESH" },
    { "code": "18", "name": "ASSAM" },
    { "code": "10", "name": "BIHAR" },
    { "code": "4", "name": "CHANDIGARH" },
    { "code": "22", "name": "CHHATTISGARH" },
    { "code": "26", "name": "DADRA AND NAGAR HAVELI AND DAMAN AND DIU" },
    { "code": "7", "name": "DELHI" },
    { "code": "30", "name": "GOA" },
    { "code": "24", "name": "GUJARAT" },
    { "code": "6", "name": "HARYANA" },
    { "code": "2", "name": "HIMACHAL PRADESH" },
    { "code": "1", "name": "JAMMU AND KASHMIR" },
    { "code": "20", "name": "JHARKHAND" },
    { "code": "29", "name": "KARNATAKA" },
    { "code": "32", "name": "KERALA" },
    { "code": "37", "name": "LADAKH" },
    { "code": "31", "name": "LAKSHADWEEP" },
    { "code": "23", "name": "MADHYA PRADESH" },
    { "code": "27", "name": "MAHARASHTRA" },
    { "code": "14", "name": "MANIPUR" },
    { "code": "17", "name": "MEGHALAYA" },
    { "code": "15", "name": "MIZORAM" },
    { "code": "13", "name": "NAGALAND" },
    { "code": "21", "name": "ODISHA" },
    { "code": "34", "name": "PUDUCHERRY" },
    { "code": "3", "name": "PUNJAB" },
    { "code": "8", "name": "RAJASTHAN" },
    { "code": "11", "name": "SIKKIM" },
    { "code": "33", "name": "TAMIL NADU" },
    { "code": "36", "name": "TELANGANA" },
    { "code": "16", "name": "TRIPURA" },
    { "code": "9", "name": "UTTAR PRADESH" },
    { "code": "5", "name": "UTTARAKHAND" },
    { "code": "19", "name": "WEST BENGAL" }
  ];
  const stateSelect = document.getElementById("state_code");
  states.forEach(s => {
    const opt = document.createElement("option");
    opt.value = s.code;
    opt.text = s.name;
    stateSelect.appendChild(opt);
  });
</script>

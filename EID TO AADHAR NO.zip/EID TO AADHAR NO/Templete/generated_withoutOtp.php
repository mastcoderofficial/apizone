<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
</head>
<?php
include('header.php');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='generated_eid_fee' "));
    $fee = $price['price'];
    $username = $udata['phone'];
    $wallet_amount = $udata['balance'];
    $debit_fee = $wallet_amount - $fee;

    if ($wallet_amount > $fee) {   
        
        $api_key="API_KEY_PASTE";  //buy Form Apizone.online
        $eid_no = $_POST['eid_no'];
        $captchaValue = $_POST['captcha'];
        $captchaTxnId = $_POST['captchaTxnId'];
        $xrequest= $_POST['xrequest'];
      
        $url="https://kycapizone.in/api/v2/Genreteid/Without.php?api_key=$api_key&eid_no=$eid_no&captchaTxnId=$captchaTxnId&captcha=$captchaValue&xrequest=$xrequest";
        $curl = curl_init();
        curl_setopt_array($curl, array( 
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
        ));

         $response = curl_exec($curl);
         curl_close($curl);
        // Execute cURL session
        $resdata = json_decode($response, true);
        // Check for cURL errors
        $status=$resdata['status'];
        $message=$resdata['message'];
        $name="KPS";
        $uidNumber=$resdata['uidNumber'];
        $enrillment=$eid_no;
        $error=$resdata['error'];
if ($error) {
            ?>
            <script>
                $(function(){
                    Swal.fire(
                        '<?php echo $error; ?>',
                        'Contact ADMIN',
                        'warning'
                    )
                });
                window.setTimeout(function(){
                    window.location.href='#';
                },4000);
            </script>
            <?php
            } else if ($uidNumber != "") {
            $debit = mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$username'");
            date_default_timezone_set("Asia/Kolkata");
            $time_hkb = date('d/m/Y g:i:s');
            $insert = mysqli_query($ahk_conn, "INSERT INTO `matching_dublicate_kps`(`aadhaar_no`, `status`, `fee`, `generated_eid`, `date`, `userid`,`message`) VALUES ('$uidNumber','$status','$fee', '$enrillment', '$time_hkb','$username','KPS')");      
            if (!$insert) {
                die('Error: ' . mysqli_error($ahk_conn));
            }
            
            $updatehistory = mysqli_query($ahk_conn,"INSERT INTO `wallethistory`(`userid`, `amount`, `balance`, `purpose`, `status`, `type`) VALUES ('$username','$fee','$debit_fee','Eid to aadhar','1','Debit')");
           if ($insert) {
                ?>
                <script>
                    $(function(){
                        Swal.fire(
                            'Aadhaar NO Found : <?php echo $uidNumber;?>',
                            'For This EID : <?php echo $enrillment; ?>!',
                            'success'
                        )
                    })
                    setTimeout(() => {
                        window.location='generated_h_list.php';    // redirect to print list 
                    }, 6000);
                </script>
                <?php
            }
        }


} else {
        ?>
        <script>
            $(function(){
                Swal.fire(
                    'Opps',
                    'Wallet Balance Insufficient! Please Recharge ',
                    'error'
                )
            });
            window.setTimeout(function(){
                window.location.href='wallet.php';      // redirect to your wallet 
            },4000);
        </script>
        <?php
    }
}
?>
<?php
$details = file_get_contents("https://kycapizone.in/api/v2/Genreteid/captcha.php");
$json = json_decode($details, TRUE);
$captcha_img = $json['image'];
$captchaTxnId = $json['txnId'];
$xrequest=$json['x_request_id'];
?>

		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
			
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="https://jeremyfagis.github.io/dropify/dist/css/dropify.min.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
 <div class="content-wrap">
    <div class="main">
        <div class="col-md-12">
            <div class="main-content">
                    <div class="section-header">
                        <div class="container-fluid">
                        </div>
                    </div>

                        <div class="container-fluid">
                            <div class="card col-12">
                                <hr>
                                <div class="row">
                                    <div class="col-lg-4 col-md-6 col-sm-6">
                                        <div class="card">
                                            <div class="card-body">
                            <div class="alert alert-danger" role="alert">
                                We Are Trying Our Best
                                <a href="#" class="alert-link"> GENERATED EID..TO AADHAR NO... </a>
                            </div>
                            <form name="" action="" method="POST" >
            <div class="form-group">
                <label for="eid_no">Enrollment Number:</label>
                <input type="text" class="form-control" id="eid_no" name="eid_no" value="<?php echo $eid_no;?>" minlength="28" maxlength="28" required>
                <p id="verificationMessage"></p>

            </div>

            <div class="form-group">
                  <img src="<?php echo $captcha_img; ?>" class="imgcaptcha" id="imgcaptcha" alt="captcha" />
                  <img src="https://kycapizone.in/api/v2/generated_eid/refresh-small.svg" href="#" onclick="location.reload(true);" style="cursor: pointer;">
                <input type="hidden" class="form-control" id="captchaTxnId" value="<?php echo $captchaTxnId; ?>" name="captchaTxnId" required>
                <input type="hidden" class="form-control" id="xrequest" value="<?php echo $xrequest; ?>" name="xrequest" required>
                
            </div>


            <div class="form-group">
                <label for="captcha">Captcha:</label>
                <input type="text" class="form-control" id="captcha" name="captcha" required>
            </div>
            <button type="submit" class="btn btn-primary">GET Aadhaar</button>
            
            <div class="col-12 ml-2">
		    	<h5 class="text-warning ">Application Fee: <?php  
		    		$price = mysqli_fetch_assoc(mysqli_query($ahk_conn,"SELECT price FROM pricing WHERE service_name='generated_eid_fee'")); 
		    		echo "₹" .$price['price'];
		    		?></h5>
		    		<hr>
										
				<a href="index.php" class="btn btn-outline-danger">Go Back<img width="30" height="30" src="https://img.icons8.com/3d-fluency/94/undo.png" alt="undo"/></a>
				<a href="generated_h_list.php" class="btn btn-outline-danger position-flex" style="right: 20px;">LIST<img width="30" height="30" src="https://img.icons8.com/arcade/64/bulleted-list.png" alt="bulleted-list"/></a>
		    </div>
          
						
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-6 col-sm-6">
                    <div class="card" style="height: 290px; background-color: #FCF3CF;">
                        <div class="card-body">
                        <h6>GENERATED EID TO AADHAAR NUMBER SERVICE</h6>
                            <hr>
                            <h6>Aadhaar No : <?php echo $resdata['uidNumber'];; ?></h6>
                            <ul>
                                <li>Generated : <?php echo $eid_no;?>.</li>
                                <li style="color:green">Cilient TxnId : <B><?php echo $resdata['txnId'];?></B>.</li>
                                <li style="color:red">Message : <B><?php echo $resdata['Message'];?></B>.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

 <!--end page wrapper -->
<?php 
include('footer.php');
?>
<!-- Bootstrap JS -->
<script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
<!--plugins-->
<script src="../template/ahkweb/assets/js/jquery.min.js"></script>
<script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<script src="../template/ahkweb/assets/plugins/chartjs/chart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/sparkline-charts/jquery.sparkline.min.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/excanvas.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/jquery.knob.js"></script>
<script>
$(function() {
    $(".knob").knob();
});
</script>
<script src="../template/ahkweb/assets/js/index.js"></script>
<!--app JS-->
<script src="../template/ahkweb/assets/js/app.js"></script>
<!-- datatable -->
<script src="../template/ahkweb/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="../template/ahkweb/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	
	<script>
		$(document).ready(function() {
			var table = $('#example2').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'pdf', 'print']
			} );
		 
			table.buttons().container()
				.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
		} );
	</script>
	
</body>



</html>
<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/generated_withoutOtp.php');
?>

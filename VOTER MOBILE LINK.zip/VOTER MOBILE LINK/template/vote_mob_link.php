<?php
include('header.php');
?>
     	<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Home </div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">New APPLY</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<button type="button" class="btn btn-primary">Settings</button>
							<button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">	<span class="visually-hidden">Toggle Dropdown</span>
							</button>
							<div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end">	<a class="dropdown-item" href="javascript:;">Action</a>
								<a class="dropdown-item" href="javascript:;">Another action</a>
								<a class="dropdown-item" href="javascript:;">Something else here</a>
								<div class="dropdown-divider"></div>	<a class="dropdown-item" href="javascript:;">Separated link</a>
							</div>
						</div>
					</div>
				</div>
<head>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <style>
        .hidden {
            display: none;
        }
    </style>
</head>
<body>

    <div class="content-wrap">
            <div class="main">
			    <div class="col-md-12">
      <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-4">
                        <div class=" bg-light rounded h-100 p-4">
                        <div class="card bg-dark">
                            <p style="color:white;"><B>VOTER MOBILE NUMBER LINK !!!</B></p>
                        </div>
<?php
// Get captcha details from the API
$details = file_get_contents("https://apizone.online/api/v2/verify_voter/captcha.php");
$json = json_decode($details, TRUE);
$captcha_img = $json['captcha'];
$captchaTxnId = $json['id'];

$api_key="api_key_paste_here"; // api key change from here apizone.online

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['find']) && !empty($_POST['epic_no'])) {
        $epic_no = $_POST['epic_no'];

        // Make API Request
        $url = file_get_contents("https://apizone.online/api/v2/verify_voter/verify_mobile_get.php?epic_no=$epic_no&api_key=$api_key");
        $result = json_decode($url, true);
        if ($result) {
            $applicantFullName = $result['name'];
            $epicNumber = $result['epicno'];
            $mobileNumber = $result['mobileNumber'];
            $stateName = $result['state'];
            $statuss = $result['status'];
            $messages = $result['message'];
            $errors = $result['error'];
        if ($statuss == 'Success') {
           echo '<div id="success-alert" class="alert alert-success" role="alert">
                  Status:  ' . $statuss . '
                 </div>';
        } else if ($errors) {
            echo '<div class="alert alert-danger" role="alert">
                   .' . $errors . ' - ' . $messages . '
                 </div>';
            echo '<script>
                    setTimeout(function () {
                        window.location = "' . $redirectUrl . '";
                    }, 5000);
                  </script>';
           }
        }
    }
}
?>

 <?php
  $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='v_mobile_link' "));
  $fee = $price['price'];
  $balance=$udata['balance'];
  $mobile = $udata['phone'];
  $debit_fee =  $balance - $fee;
  if($balance>$fee){
      
        if (isset($_POST['submit_mobile']) && !empty($_POST['new_mobile'])) {
            $newMobileNumber = $_POST['new_mobile'];
            $epic = $_POST['epic'];
            $place = $_POST['place'];
            $ptp = $_POST['otp'];

            $captchap = $_POST['captcha'];
            $captchaid = $_POST['captchaTxnId'];

            $apiUrl = file_get_contents("https://apizone.online/api/v2/verify_voter/form_8.php?api_key=".urlencode($api_key)."&epic=".urlencode($epic)."&otp=".urlencode($ptp)."&new_mobile=".urlencode($newMobileNumber)."&place=".urlencode($place)."&captcha=".urlencode($captchap)."&captchaTxnId=".urlencode($captchaid));

            $ch = curl_init($apiUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);

            if ($apiUrl === false) {
                echo '<div class="alert alert-danger" role="alert">
                        cURL request failed
                      </div>';
            } else {
                $data = json_decode($apiUrl, true);
                $status = $data['status'];
                $message = $data['message'];
                $refId = $data['refId'];
                $rerror = $data['error'];

                $alertType = $status == "Success" ? 'success' : 'success';
                $redirectUrl = $status == "Success" ? "" : "' . $redirectUrl . '";
                
                // debited code and save card summary 
                if($refId !=''){
                  mysqli_query($ahk_conn, "UPDATE users SET balance = balance - $fee WHERE phone='$mobile'");
                  $new_balance = $balance - $fee;
                  date_default_timezone_set("Asia/Kolkata");
                  $timestamp = date('d/m/Y g:i:s');
                  $cardinst = "INSERT INTO m_link(epic_no, mobile_no, response, userid, date) VALUES ('$epic','$newMobileNumber','$message','$mobile','$timestamp')";
                  $updatehistory = mysqli_query($ahk_conn,"INSERT INTO wallethistory(userid, amount, balance, purpose, status, type) VALUES ('$mobile','$fee','$debit_fee','$epic Voter Mobile Link','1','Debit')");
                  $res = mysqli_query($ahk_conn, $cardinst);   
    
                }
   
     
               echo "<script>
        Swal.fire({
          title: '$rerror!',
          text: 'Mobile Number Link $status Your Reference No: $refId - $message',
          icon: '$alertType',
          confirmButtonText: 'OK'
        });
      </script>";

                echo '<script>
                        setTimeout(function () {
                            window.location = "";
                        }, 5000);
                      </script>';
            }

            curl_close($ch);
        }
  }else{
     $msg="<script>
        Swal.fire({
          title:'Balance Low ! Recharge Now',
          text:  'Warning!',
          icon: 'warning',
          confirmButtonText: 'OK'
        }).then((result) => {
          if (result.isConfirmed) {
            window.location = 'wallet.php';
          }
        });
      </script>";
}
        ?>

				<!--end breadcrumb-->
        <div class="main">
            <div class="col-md-12">
                <div class="main-content">
                    <div class="col-md-12">
                        <div class="card card-default">
                            <div class="card-header bg-warning">
                                <div class="card-title">
                                    <h3><strong>ENTER VOTER DETAILS</strong></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                            <h6 > <?php echo $msg; ?></h6>
          <!-- Form 1: Enter EPIC number -->
          <div class="card">
             <form id="epic_form" class="user <?php echo ($epicNumber) ? 'hidden' : ''; ?>" method="POST">
                 <div class="form-group">
                     <label for="epic_no">EPIC NO<span class="text-danger">*</span></label>
                     <input id="epic_no" name="epic_no" class="form-control border-success" type="text" value="<?php echo $epicNumber; ?>" required <?php echo ($epicNumber) ? 'disabled' : ''; ?>>
                 </div>
   <br>
                 <button type="submit" name="find" class="btn btn-primary w-100" <?php echo ($epicNumber) ? 'disabled' : ''; ?>>
                     <i class="fa fa-check-circle"></i>Verify
                 </button>
                   <div class="col-12 ml-2">
				   	<h5 class="text-warning ">Application Fee: <?php  
				   		$price = mysqli_fetch_assoc(mysqli_query($ahk_conn,"SELECT price FROM pricing WHERE service_name='v_mobile_link'")); 
				   		echo "₹" .$price['price'];
				   		?></h5>
				   </div>
             </form>


            <!-- Form 2: Displayed upon successful first API response -->
            <form id="additional_fields_form" class="user <?php echo ($epicNumber) ? '' : 'hidden'; ?>" method="POST">
                 <div class="form-group">
                    <label for="">Full Name<span class="text-danger">*</span></label>
                    <input id="" name="" class="form-control" type="" readonly value="<?php echo $applicantFullName; ?>" required>
                </div> 
                <div class="form-group">
                    <label for="new_mobile">New Mobile Number<span class="text-danger">*</span></label>
                    <input id="epic" name="epic" class="form-control" type="hidden" value="<?php echo $epicNumber; ?>" required>
                    <input id="new_mobile" name="new_mobile" class="form-control border-primary" type="number" placeholder="ENTER NEW MOBILE NUMBER" value="<?php echo $mobileNumber; ?>" required>
                                   
                     <button type="button" id="getOTPButton" class="btn btn-primary w-100"><i class="fa fa-check-circle"></i>Get OTP</button>
                </div>
                <div class="form-group">
                    <label for="otp">OTP<span class="text-danger">*</span></label>
                    <input id="otp" name="otp" class="form-control border-primary" type="number" placeholder="ENTER 6 DIGIT OTP" value="" required>
                </div>
                <!--<div class="form-group">-->
                    <!--<label for="place">Ca<span class="text-danger">*</span></label>-->
                <!--    <img src="data:application/image;base64,<?php echo $captcha_img; ?>"  class="border-primary mt-2" alt="captchaa" />-->
                <!--</div>-->
                <div class="form-group">
                    <!--<label for="captcha">Enter Captcha<span class="text-danger">*</span></label>-->
                    <input id="captcha" name="captcha" class="form-control border-primary" type="hidden" placeholder="Enter Captcha Code" value="1jkiZds" required>
                    <input id="captchaTxnId" name="captchaTxnId" class="form-control border-primary" readonly type="hidden" value="<?php echo $captchaTxnId; ?>" required>
                    <input id="place" name="place" class="form-control border-primary" readonly type="hidden" value="<?php echo $stateName; ?>" required>
                </div>
<br>
               <button type="submit" name="submit_mobile" class="btn btn-primary w-100"><i class="fa fa-check-circle"></i>Submit</button>
            </form>
        </div>
    </div>
</div>
<script>
document.getElementById('getOTPButton').addEventListener('click', function() {
    var newMobile = document.getElementById('new_mobile').value;
    // Make API call with API key
    fetch(`https://apizone.online/api/v2/verify_voter/send_otp.php?new_mobile=${newMobile}`)
    .then(response => {
        return response.json();
    })
    .then(data => {
        console.log('API response:', data);
        if (data.error) {
            // Display error message in alert
            alert(data.error);
        } else if (data.message) {
            // Display message from API in alert
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while sending OTP. Please try again later.');
    });
});
</script>
    <!-- Add your footer content here -->

    <script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
    <script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
    <script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
    <script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
    <script src="../template/ahkweb/assets/js/app.js"></script>
<script>
    // Hide the success and error alerts after 3 seconds
    setTimeout(function () {
        document.getElementById('success-alert').style.display = 'none';
        // document.getElementById('error-alert').style.display = 'none';
    }, 3000);
</script>

</body>
</html>
<?php
include('userFooter.php');
?>

<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/header.php');

$appliedby = $_SESSION['phone'] ?? '';
if (!$appliedby) die("Please login first.");

$udata = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM users WHERE phone='$appliedby'"));
$old_balance = $udata['balance'];

$api_zone = "API_KEY_PASTE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )
$step = 1;
$message = "";

$epic_no = $_POST['epic_no'] ?? '';
$new_mobile = $_POST['new_mobile'] ?? '';
$otp = $_POST['otp'] ?? '';
$voter_details = $_SESSION['voter_details'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['step'] == 'verify_epic') {
        $epic_no = trim($_POST['epic_no']);
        $url = "https://kycapizone.in/api/v2/voter/epic_verify.php?api_key=$api_zone&epic_no=" . urlencode($epic_no);
        $response = file_get_contents($url);
        $result = json_decode($response, true);

        if ($result['response_code'] == '200' && !empty($result['result'])) {
            $voter_details = $result['result'];
            $_SESSION['voter_details'] = $voter_details;
            $_SESSION['epic_no'] = $epic_no;
            $step = 2;
            $message = "✅ EPIC Verified. Please enter new mobile number.";
        } else {
            $message = "❌ EPIC Verification failed: " . ($result['response_message'] ?? 'Unknown error');
            $step = 1;
        }
    } elseif ($_POST['step'] == 'send_otp') {
        $epic_no = $_SESSION['epic_no'] ?? '';
        $voter_details = $_SESSION['voter_details'] ?? null;

        $fee = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT price FROM pricing WHERE service_name='voter_original_fee'"))['price'];
        if ($old_balance < $fee) {
            $message = "❌ Insufficient balance.";
            $step = 2;
        } else {
            $new_balance = $old_balance - $fee;
            mysqli_query($ahk_conn, "UPDATE users SET balance=$new_balance WHERE phone='$appliedby'");
            mysqli_query($ahk_conn, "INSERT INTO wallethistory (userid, amount, old_balance, balance, purpose, status, type) VALUES ('$appliedby', '$fee', '$old_balance', '$new_balance', 'VOTER MOBILE LINK', 'Success', 'Debit')");

            $otp_url = "https://kycapizone.in/api/v2/voter/v_change_send_otp.php?api_key=$api_zone&mobile_no=$new_mobile";
            $otp_response = file_get_contents($otp_url);
            $otp_result = json_decode($otp_response, true);

            if ($otp_result['response_code'] == '200') {
                $_SESSION['new_mobile'] = $new_mobile;
                $message = "✅ OTP sent to $new_mobile.";
                $step = 3;
            } else {
                mysqli_query($ahk_conn, "UPDATE users SET balance=$old_balance WHERE phone='$appliedby'");
                mysqli_query($ahk_conn, "INSERT INTO wallethistory (userid, amount, old_balance, balance, purpose, status, type) VALUES ('$appliedby', '$fee', '$new_balance', '$old_balance', 'VOTER MOBILE LINK REFUND', 'Refunded', 'Credit')");
                $message = "❌ OTP send failed: " . ($otp_result['response_message'] ?? 'Unknown error');
                $step = 2;
            }
        }
    } elseif ($_POST['step'] == 'verify_otp_update_mobile') {
        $epic_no = $_SESSION['epic_no'] ?? '';
        $new_mobile = $_SESSION['new_mobile'] ?? '';
        $data_array = [
            'mobileNumber' => $new_mobile,
            'epic_no' => $epic_no,
            'otp' => $otp
        ];
        $encoded_data = base64_encode(json_encode($data_array));
        $url = "https://kycapizone.in/api/v2/voter/voter_change_mob.php?data=$encoded_data&api_key=$api_zone";
        $response = file_get_contents($url);
        $result = json_decode($response, true);

        if ($result && $result['response_code'] == '200') {
            $message = "✅ Mobile number updated successfully!";
            $step = 4;
        } else {
            $message = "❌ Update failed: " . ($result['response_message'] ?? 'Unknown error');
            $step = 3;
        }
    }
}
?>

     	<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
			
<head>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <style>
        .hidden {
            display: none;
        }
    </style>
</head>
<body>

    <div class="content-wrap">
            <div class="main">
    <div class="card shadow p-4">
        <h4 class="mb-3">Voter Mobile Number Update</h4>

        <?php if ($message): ?>
            <div class="alert alert-info"><?php echo $message; ?></div>
        <?php endif; ?>

        <?php if ($step == 1): ?>
            <form method="POST">
                <div class="mb-3">
                    <label>Enter EPIC Number</label>
                    <input type="text" name="epic_no" class="form-control" required>
                </div>
                <input type="hidden" name="step" value="verify_epic">
                <button class="btn btn-primary">Verify EPIC</button>
            </form>

        <?php elseif ($step == 2): ?>
            <h5>Voter Details</h5>
            <table class="table table-bordered">
                <tr><th>Full Name</th><td><?= htmlspecialchars($voter_details['fullName'] ?? '') ?></td></tr>
                <tr><th>Father Name</th><td><?= htmlspecialchars($voter_details['relativeFullName'] ?? '') ?></td></tr>
                <tr><th>Age</th><td><?= htmlspecialchars($voter_details['age'] ?? '') ?></td></tr>
                <tr><th>Gender</th><td><?= htmlspecialchars($voter_details['gender'] ?? '') ?></td></tr>
                <tr><th>District</th><td><?= htmlspecialchars($voter_details['districtValue'] ?? '') ?></td></tr>
                <tr><th>State</th><td><?= htmlspecialchars($voter_details['stateName'] ?? '') ?></td></tr>
            </table>
            <form method="POST">
                <div class="mb-3">
                    <label>New Mobile Number</label>
                    <input type="text" name="new_mobile" class="form-control" required pattern="\d{10}" maxlength="10">
                </div>
                <input type="hidden" name="step" value="send_otp">
                <button class="btn btn-warning">Send OTP</button>
            </form>

        <?php elseif ($step == 3): ?>
            <form method="POST">
                <div class="mb-3">
                    <label>Enter OTP sent to <?= htmlspecialchars($new_mobile) ?></label>
                    <input type="text" name="otp" class="form-control" required pattern="\d{4,6}" maxlength="6">
                </div>
                <input type="hidden" name="step" value="verify_otp_update_mobile">
                <button class="btn btn-success">Verify OTP & Update</button>
            </form>

        <?php elseif ($step == 4): ?>
            <?php
                $status = htmlspecialchars($result['status'] ?? '');
                $code = htmlspecialchars($result['code'] ?? '');
                $msg = htmlspecialchars($result['message'] ?? '');
                $refId = htmlspecialchars($result['refId'] ?? '');
                $inner = $result['result'] ?? [];
            ?>
            <div class="alert alert-success">
                <strong>✅ Mobile updated for EPIC:</strong> <?= htmlspecialchars($epic_no) ?><br>
                New Mobile: <strong><?= htmlspecialchars($new_mobile) ?></strong><br><br>
                <strong>API Status:</strong> <?= $status ?> | Code: <?= $code ?> | Ref ID: <?= $refId ?><br>
                Message: <?= $msg ?><br><br>
                <strong>Inner Status:</strong> <?= htmlspecialchars($inner['success'] ?? '') ?> | Code: <?= htmlspecialchars($inner['response_code'] ?? '') ?> | Ref ID: <?= htmlspecialchars($inner['refId'] ?? '') ?><br>
                Message: <?= htmlspecialchars($inner['message'] ?? '') ?><br>
            </div>
            <a href="vote_mob_link.php" class="btn btn-dark">Start New Update</a>
        <?php endif; ?>
    </div>
</div>
</body>
</html>



<?php include('footer.php'); ?>

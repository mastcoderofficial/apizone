<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/header.php');

// Fetch Fee
$price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='AadhaarDetails_Fee'"));
$fee = $price['price'];
$resdata = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['uidNumber'])) {
    $uidNumber = trim($_POST['uidNumber']);
    $appliedby = $udata['phone'];
    $debit_fee = $udata['balance'] - $fee;

    if ($udata['balance'] >= $fee) {
        $api_zone = "API_KEY_PASTE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )
        $url = "https://kycapizone.in/api/v2/Aadhar_Advance/aadhaar_details.php?api_key=$api_zone&aadhaar_no=$uidNumber";

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CUSTOMREQUEST => 'GET',
        ));
        $response = curl_exec($curl);
        curl_close($curl);

        $apiResult = json_decode($response, true);

        if ($apiResult && $apiResult['success'] === true && $apiResult['response_code'] === '200') {
            $resdata = $apiResult['result'];

            // Wallet debit
            mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$appliedby'");
            mysqli_query($ahk_conn, "INSERT INTO wallethistory(userid, amount, balance, purpose, status, type) VALUES ('$appliedby', '$fee', '$debit_fee', 'Aadhaar Detail Fetch', '1', 'Debit')");
        } else {
            echo "<script>Swal.fire('Failed', 'API Error: " . htmlspecialchars($apiResult['response_message'] ?? 'Unknown error') . "', 'error');</script>";
        }
    } else {
        echo "<script>Swal.fire('Low Balance', 'Please recharge your wallet!', 'warning');</script>";
    }
}
?>

<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
    <div class="row">
      <!-- Left Panel -->
      <div class="col-md-4">
        <form method="POST" class="card p-3 shadow">
          <h5 class="mb-3 text-danger">Aadhaar Details</h5>
          <div class="form-group mb-2">
            <label>Aadhaar Number</label>
            <input type="text" name="uidNumber" maxlength="12" minlength="12" required class="form-control" placeholder="Enter 12-digit UID">
          </div>
          <div class="form-group mb-3">
            <label>Fee</label>
            <input type="text" class="form-control" value="₹ <?php echo $fee; ?>" readonly>
          </div>
          <button type="submit" class="btn btn-success w-100"><i class="fa fa-search"></i> Submit</button>
        </form>
      </div>

      <!-- Right Panel -->
      <?php if (!empty($resdata)): ?>
      <div class="col-md-8">
        <div class="card p-3 shadow" style="background:#f9fdfc;">
          <h5>📄 Aadhaar Detail Report</h5>
          <table class="table table-bordered table-striped">
            <tr><th>Aadhaar No</th><td><?= htmlspecialchars($resdata['aadhaar_no'] ?? '-') ?></td></tr>
            <tr><th>Name</th><td><?= htmlspecialchars($resdata['name'] ?? '-') ?></td></tr>
            <tr><th>Date of Birth</th><td><?= htmlspecialchars($resdata['dateOfBirth'] ?? '-') ?></td></tr>
            <tr><th>Gender</th><td><?= htmlspecialchars($resdata['gender'] ?? '-') ?></td></tr>
            <tr><th>Relation Type</th><td><?= htmlspecialchars($resdata['relation_type'] ?? '-') ?></td></tr>
            <tr><th>Relative Name</th><td><?= htmlspecialchars($resdata['r_name'] ?? '-') ?></td></tr>
            <tr><th>Mobile</th><td><?= htmlspecialchars($resdata['mobile'] ?? '-') ?></td></tr>
            <tr><th>Full Address</th><td><?= htmlspecialchars($resdata['full_address'] ?? '-') ?></td></tr>
            <tr>
              <th>Photo</th>
              <td>
                <?php if (!empty($resdata['photo'])): ?>
                  <img src="<?= $resdata['photo'] ?>" style="height:150px;border:1px solid #aaa;">
                <?php else: ?>
                  No Photo Available
                <?php endif; ?>
              </td>
            </tr>
          </table>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include('footer.php'); ?>

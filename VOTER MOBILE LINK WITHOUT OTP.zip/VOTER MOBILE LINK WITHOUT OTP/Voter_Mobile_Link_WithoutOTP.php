<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/header.php');

$fee = '20';
$resdata = null;

if (!empty($_POST['epic_number']) && !empty($_POST['mob_number'])) {
    $epic_number = $_POST['epic_number'];
    $mob_number = $_POST['mob_number'];

    $appliedby = $udata['phone'];
    $debit_fee = $udata['balance'] - $fee;

    if ($udata['balance'] >= $fee) {
        $api_zone = "API_KEY_PASTE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )
        $url = "https://kycapizone.in/api/v2/voter/voter_mobile_update_withoutotp.php?api_key=$api_zone&mob_number=$mob_number&epic_number=$epic_number";

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 60,
        ]);
        $response = curl_exec($curl);
        curl_close($curl);

        $resdata = json_decode($response, true);

        if (!isset($resdata['success']) || $resdata['success'] !== true) {
            $errorMsg = isset($resdata['response_message']) ? $resdata['response_message'] : "Failed";
            echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
            <script>
                Swal.fire({ 
                    icon: 'error', 
                    title: 'Error', 
                    text: '".addslashes($errorMsg)."', 
                    timer: 5000 
                });
                setTimeout(() => { window.location = ''; }, 5000);
            </script>";
            exit;
        }

        if ($resdata['response_code'] == '100' && isset($resdata['result'])) {
            mysqli_query($ahk_conn, "UPDATE users SET balance = balance - $fee WHERE phone = '$appliedby'");
            mysqli_query($ahk_conn, "INSERT INTO wallethistory(userid, amount, balance, purpose, status, type) VALUES ('$appliedby', '$fee', '$debit_fee', 'Voter 2 Mobile Link Without Otp Verification', '1', 'Debit')");
        } else {
            echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
            <script>
                Swal.fire({ 
                    icon: 'error', 
                    title: 'Error', 
                    text: 'Unexpected API response', 
                    timer: 4000 
                });
                setTimeout(() => { window.location = ''; }, 4000);
            </script>";
            exit;
        }
    } else {
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
        <script>
            Swal.fire({ 
                icon: 'error', 
                title: 'Wallet Balance is Low!', 
                text: 'Please Recharge Now!', 
                timer: 2000 
            });
            setTimeout(() => { window.location = 'wallet.php'; }, 2000);
        </script>";
        exit;
    }
}
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
    <div class="row">
      <!-- Left Panel -->
            <div class="page-content">
                <div class="mobile-menu-overlay"></div>
                <div class="main-container">
                    <div class="col-lg-12">
                        <div class="card" style="margin-left: 10px; padding-left: 30px; padding-top: 12px; box-shadow: 1px 5px 5px 5px;">
                            <div class="stat-widget-two">
                                <div class="stat-content">
                                    <div class="stat-text">
                                        <div class="container-fluid">
                                            <div class="row">
                                                <div class="col-lg-4 col-md-6 col-sm-6">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <div class="alert alert-info" role="alert">
                                                                Voter 2 Mobile Link Without OTP Verification
                                                            </div>
                                                            <form action="" method="POST" class="row g-3">
                                                                <div class="card-body">
                                                                    <div class="col-md-12">
                                                                        <div class="form-group">
                                                                            <label for="epic_number">Enter Voter Number</label>
                                                                            <input name="epic_number" type="text" id="epic_number" placeholder="Enter Voter Number" class="form-control" required>
                                                                        </div>
                                                                        <div class="form-group mt-2">
                                                                            <label for="mob_number">Enter Mobile Number</label>
                                                                            <input name="mob_number" type="text" id="mob_number" placeholder="Enter Mobile Number" class="form-control" required>
                                                                        </div>
                                                                        <hr>
                                                                        <div class="row mt-3">
                                                                            <div class="col-md-6">
                                                                                <input class="form-control" value="Fee ₹ <?php echo $fee; ?>" readonly>
                                                                            </div>
                                                                            <div class="col-md-6 text-end">
                                                                                <button class="btn btn-primary" name="submit" id="submit"><i class="fa fa-check-circle"></i> Submit</button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>

<?php
if (!empty($resdata) && isset($resdata['response_code']) && $resdata['response_code'] === "100") {
    $result = $resdata['result'];
    $aadharDisplay = htmlspecialchars($epic_number);
    $panDisplay = htmlspecialchars($mob_number);
?>
                                                <div class="col-lg-8 col-md-6 col-sm-6">
                                                    <div class="card" style="background-color: #E8F6F3;">
                                                        <div class="card-body">
                                                            <div id="capture-area" style="padding: 10px; background: white; color: black;">
                                                                <h5 class="mb-3">Voter 2 Mobile Link Without OTP Instant</h5>
                                                                <table class="table table-bordered table-striped">
                                                                    <tbody>
                                                                        <tr><th>Voter Number</th><td><?php echo $aadharDisplay; ?></td></tr>
                                                                        <tr><th>Mobile Number</th><td><?php echo htmlspecialchars($result['mob_number']); ?></td></tr>
                                                                        <tr><th>Full Name</th><td><?php echo htmlspecialchars($result['fullname']); ?></td></tr>
                                                                        <tr><th>Reference Number</th><td><?php echo htmlspecialchars($result['referenceNumber']); ?></td></tr>
                                                                        <tr><th>State Name</th><td><?php echo htmlspecialchars($result['state']); ?></td></tr>
                                                                        <tr><th>Message</th><td><?php echo htmlspecialchars($result['message']); ?></td></tr>
                                                                    </tbody>
                                                                </table>
                                                                <p style="margin-top: 20px; font-weight: bold; text-align: center;">Developed by APIZONE.CO.IN</p>
                                                                <div class="text-center">
                                                                    <button id="downloadBtn" class="btn btn-success mt-3">Download PNG</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

<script>
    const aadharNumber = "<?php echo $aadharDisplay; ?>";
    const panNumber = "<?php echo $panDisplay; ?>";
</script>
<?php } ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
    document.getElementById("downloadBtn")?.addEventListener("click", function () {
        const element = document.getElementById("capture-area");
        html2canvas(element).then(canvas => {
            const image = canvas.toDataURL("image/png");
            const link = document.createElement("a");
            link.href = image;
            link.download = "voter_2_mobile_link_<?php echo $epic_number; ?>.png";
            link.click();
        });
    });
</script>

<?php include('footer.php'); ?>

<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/shram_card_3_aadhar_detail.php');

?>

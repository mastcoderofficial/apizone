<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/header.php');

// PAN Verification logic
if (isset($_POST['verify_pan'])) {
    $pan_no = $_POST['pan_no'];

        $api_zone = "API_KEY_PASTE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )

    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='pan_no' "));
    $fee = $price['price'];
    $username = $udata['phone'];
    $wallet_amount = $udata['balance'];

    if ($wallet_amount < $fee) {
        ?>
        <script>
            $(function() {
                Swal.fire('Insufficient Balance', 'Your wallet balance is too low.', 'error');
            });
            setTimeout(() => { window.location.href = 'wallet.php'; }, 2000);
        </script>
        <?php
    } else {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://kycapizone.in/api/v2/pan_advance/Panplus.php?api_key=$api_zone&pan=$pan_no",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        $json = json_decode($response, true);

        if ($err || $json['response_code'] != "100") {
            $debit_fee = $wallet_amount - $fee;
            mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$username'");
            mysqli_query($ahk_conn, "INSERT INTO `wallethistory`(`userid`, `amount`, `balance`, `purpose`, `status`, `type`) 
                VALUES ('$username','$fee','$debit_fee','PAN Verify Failed','1','Debit')");

            ?>
            <script>
                $(function() {
                    Swal.fire('Failed', 'PAN not found or invalid. Amount deducted.', 'error');
                });
            </script>
            <?php
        } else {
            $r = $json['result'];
            $pan_number = $r['PAN'];
            $first_name = $r['FIRST_NAME'];
            $middle_name = $r['MIDDLE_NAME'];
            $last_name = $r['LAST_NAME'];
            $father_name = $r['FATHER_NAME'];
            $aadhaar_number = $r['AADHAR_NUM'];
            $aadhaar_linked_status = $r['AADHAR_LINKED'] ? 'Linked' : 'Not Linked';
            $dob_verified = $r['DOB_VERIFIED'] ? 'Yes' : 'No';
            $dob = $r['DOB'];
            $gender = $r['GENDER'];
            $address = $r['FULL_ADDRESS'];

            $full_name = trim("$first_name $middle_name $last_name");

            date_default_timezone_set("Asia/Kolkata");
            $time_hkb = date('d/m/Y g:i:s');

            $debit_fee = $wallet_amount - $fee;
            mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$username'");
            mysqli_query($ahk_conn, "INSERT INTO `pan_verify_hkb`(`name`, `fathername`, `gender`, `dob`, `pan`, `username`, `date`) 
                VALUES ('$full_name','$father_name','$gender','$dob','$pan_number','$username','$time_hkb')");
            mysqli_query($ahk_conn, "INSERT INTO `wallethistory`(`userid`, `amount`, `balance`, `purpose`, `status`, `type`) 
                VALUES ('$username','$fee','$debit_fee','PAN Plus Verified','1','Debit')");

            $data = [
                'api_key' => $senurlkey,
                'sender' => $sendurlsender,
                'number' => "91$username",
                'message' => "✅ PAN+ VERIFIED!\nUser: $username\nPAN: $pan_number\nName: *$full_name*\nFather: $father_name\nDOB: $dob\nGender: $gender\nAadhaar: $aadhaar_number\nLinked: $aadhaar_linked_status\nVerified DOB: $dob_verified\n\nThanks for using *SERVICE 4 PAN+*!"
            ];
        }
    }
}
?>

<!-- HTML FRONTEND -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="main">
            <div class="col-lg-12">
                <div class="card" style="margin-left: 10px; padding-left: 30px; padding-top: 12px; box-shadow: 1px 5px 5px 5px;">
                    <div class="container-fluid">
                        <div class="row">
                            <!-- Form -->
                            <div class="col-lg-4 col-md-6">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="alert alert-danger">
                                            PAN Plus Verification Service
                                        </div>
                                        <form method="post">
                                            <div class="form-group">
                                                <label for="pan_no">Enter PAN Number</label>
                                                <input type="text" required class="form-control" name="pan_no" id="pan_no" placeholder="ENTER PAN NUMBER">
                                            </div>
                                            <div class="btn btn-outline-primary">
<h5 class="text-success">Application Fee: <?php $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT price FROM pricing WHERE service_name='pan_no'")); echo "₹ " . $price['price']; ?></h5>                                            </div>
                                            <br>
                                            <button type="submit" name="verify_pan" class="btn btn-success btn-block">
                                                <i class="fa fa-check-circle"></i> Verify PAN+
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Result Display -->
                            <div class="col-lg-8 col-md-6">
                                <div class="card" style="background-color: #c7f0d8;">
                                    <div class="card-body">
                                        <h6>PAN+: Extended Details (Verification Only)</h6>
                                        <hr>
                                        <h6>Pan Number: <?php echo isset($pan_number) ? $pan_number : ''; ?></h6>
                                        <h6>Name: <?php echo isset($full_name) ? $full_name : ''; ?></h6>
                                        <h6>Father Name: <?php echo isset($father_name) ? $father_name : ''; ?></h6>
                                        <h6>Gender: <?php echo isset($gender) ? $gender : ''; ?></h6>
                                        <h6>Date of Birth: <?php echo isset($dob) ? $dob : ''; ?></h6>
                                        <h6>Aadhaar (Masked): <?php echo isset($aadhaar_number) ? $aadhaar_number : ''; ?></h6>
                                        <h6>Aadhaar Linked: <?php echo isset($aadhaar_linked_status) ? $aadhaar_linked_status : ''; ?></h6>
                                        <h6>DOB Verified: <?php echo isset($dob_verified) ? $dob_verified : ''; ?></h6>
                                        <h6>Address: <?php echo isset($address) ? $address : ''; ?></h6>
                                        <hr>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- row -->
                    </div> <!-- container -->
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

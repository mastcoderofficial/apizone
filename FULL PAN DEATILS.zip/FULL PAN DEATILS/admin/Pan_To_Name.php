<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/header.php');

if (isset($_POST['verify_pan'])) {
    $pan_no = $_POST['pan_no'];

        $api_zone = "API_KEY_PASTE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )

    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='pan_no' "));
    $fee = $price['price'];
    $username = $udata['phone'];
    $wallet_amount = $udata['balance'];

    if ($wallet_amount < $fee) {
        ?>
        <script>
            $(function() {
                Swal.fire('Insufficient Balance', 'Recharge your wallet to proceed.', 'error');
            });
            setTimeout(() => { window.location.href = 'wallet.php'; }, 2000);
        </script>
        <?php
    } else {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "http://kycapizone.in/api/v2/pan_advance/pan_to_name.php?api_key=$api_zone&pan_no=$pan_no",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        $json = json_decode($response, true);

        if ($err || $json['response_code'] != "100") {
            $debit_fee = $wallet_amount - $fee;
            mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$username'");
            mysqli_query($ahk_conn, "INSERT INTO wallethistory(userid, amount, balance, purpose, status, type) 
                VALUES ('$username', '$fee', '$debit_fee', 'PAN Name Fetch Failed', '1', 'Debit')");
            ?>
            <script>
                $(function() {
                    Swal.fire('Verification Failed', 'PAN not found or invalid. Amount deducted.', 'error');
                });
            </script>
            <?php
        } else {
            $r = $json['result'];
            $pan_number = $r['pan_number'];
            $name = $r['name'];
            $masked_aadhaar = $r['maskedAadhaar'];
            $api_message = $r['message'];
            $datetime = $r['datetime'];

            date_default_timezone_set("Asia/Kolkata");
            $now = date('d/m/Y g:i:s');

            $debit_fee = $wallet_amount - $fee;
            mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$username'");
            mysqli_query($ahk_conn, "INSERT INTO pan_verify_hkb(name, pan, username, date) 
                VALUES ('$name', '$pan_number', '$username', '$now')");
            mysqli_query($ahk_conn, "INSERT INTO wallethistory(userid, amount, balance, purpose, status, type) 
                VALUES ('$username', '$fee', '$debit_fee', 'PAN to Name Fetch', '1', 'Debit')");

            $data = [
                'api_key' => $senurlkey,
                'sender' => $sendurlsender,
                'number' => "91$username",
                'message' => "✅ PAN to Name Verified!\nUser: $username\nPAN: $pan_number\nName: *$name*\nMasked Aadhaar: $masked_aadhaar\nStatus: $api_message\nTime: $datetime\n\nThanks for using *SERVICE 4 PAN NAME*!"
            ];
        }
    }
}
?>

<!-- HTML CONTENT -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="main">
            <div class="col-lg-12">
                <div class="card" style="margin-left: 10px; padding: 15px; box-shadow: 1px 5px 5px 5px;">
                    <div class="container-fluid">
                        <div class="row">
                            <!-- Form -->
                            <div class="col-lg-4 col-md-6">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="alert alert-danger">
                                            PAN to Name Verification
                                        </div>
                                        <form method="post">
                                            <div class="form-group">
                                                <label for="pan_no">Enter PAN Number</label>
                                                <input type="text" required class="form-control" name="pan_no" id="pan_no" placeholder="ENTER PAN NUMBER">
                                            </div>
                                            <div class="btn btn-outline-primary">


                                            </div>
                                            <br>
                                            <button type="submit" name="verify_pan" class="btn btn-success btn-block">
                                                <i class="fa fa-check-circle"></i> Verify PAN Name
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Result Display -->
                            <div class="col-lg-8 col-md-6">
                                <div class="card" style="background-color: #c7f0d8;">
                                    <div class="card-body">
                                        <h6>PAN to Name: Result</h6>
                                        <hr>
                                        <h6>Pan Number: <?php echo isset($pan_number) ? $pan_number : ''; ?></h6>
                                        <h6>Name: <?php echo isset($name) ? $name : ''; ?></h6>
                                        <h6>Masked Aadhaar: <?php echo isset($masked_aadhaar) ? $masked_aadhaar : ''; ?></h6>
                                        <h6>Status: <?php echo isset($api_message) ? $api_message : ''; ?></h6>
                                        <h6>Date & Time: <?php echo isset($datetime) ? $datetime : ''; ?></h6>
                                        <hr>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- row -->
                    </div> <!-- container -->
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

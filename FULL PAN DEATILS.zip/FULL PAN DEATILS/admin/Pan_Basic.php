<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/header.php');

// Check if PAN is submitted
if (isset($_POST['verify_pan'])) {
    $pan_no = $_POST['pan_no'];

    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='pan_no' "));
    $fee = $price['price'];
    $username = $udata['phone'];
    $wallet_amount = $udata['balance'];

        $api_zone = "API_KEY_PASTE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )
    // Check wallet balance
    if ($wallet_amount < $fee) {
        ?>
        <script>
            $(function() {
                Swal.fire('Insufficient Balance', 'Your wallet balance is too low to process this request', 'error');
            });
            setTimeout(() => { window.location.href = 'wallet.php'; }, 2000);
        </script>
        <?php
    } else {
        // API Request
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://kycapizone.in/api/v2/pan_advance/panbasic.php?api_key=$api_zone&pan_no=$pan_no",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        $json = json_decode($response, true);

        if ($err || $json['response_code'] != "100") {
            // Deduct fee from wallet even if API fails
            $debit_fee = $wallet_amount - $fee;
            mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$username'");
            mysqli_query($ahk_conn, "INSERT INTO `wallethistory`(`userid`, `amount`, `balance`, `purpose`, `status`, `type`) 
                VALUES ('$username','$fee','$debit_fee','PAN Verify Failed','1','Debit')");

            ?>
            <script>
                $(function() {
                    Swal.fire('Verification Failed', 'Invalid PAN or Data Not Found. Amount has been deducted.', 'error');
                });
            </script>
            <?php
        } else {
            $pan_number = $json['result']['pan_no'];
            $full_name = $json['result']['full_name'];
            $dob = $json['result']['date_of_birth'];
            $valid_status = $json['result']['is_valid'];

            date_default_timezone_set("Asia/Kolkata");
            $time_hkb = date('d/m/Y g:i:s');

            // Deduct fee
            $debit_fee = $wallet_amount - $fee;
            mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$username'");
            mysqli_query($ahk_conn, "INSERT INTO `pan_verify_hkb`(`name`, `fathername`, `gender`, `dob`, `pan`, `username`,`date`) 
                VALUES ('$full_name','-','-','$dob','$pan_number','$username','$time_hkb')");
            mysqli_query($ahk_conn, "INSERT INTO `wallethistory`(`userid`, `amount`, `balance`, `purpose`, `status`, `type`) 
                VALUES ('$username','$fee','$debit_fee','PAN Details Verify','1','Debit')");

            // SMS Send
            $data = [
                'api_key' => $senurlkey,
                'sender' => $sendurlsender,
                'number' => "91$username",
                'message' => "✅ PAN VERIFIED!\nUser: $username\nPAN: $pan_number\nName: *$full_name*\nDOB: $dob\nStatus: $valid_status\n\nThank you for using *SERVICE 4 PAN*!\nJoin Group: https://chat.whatsapp.com/KBogmWHCncwJPKyZW3LGZ1"
            ];
        }
    }
}
?>

<!-- HTML CONTENT START -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="main">
            <div class="col-lg-12">
                <div class="card" style="margin-left: 10px; padding-left: 30px; padding-top: 12px; box-shadow: 1px 5px 5px 5px;">
                    <div class="stat-widget-two">
                        <div class="stat-content">
                            <div class="container-fluid">
                                <div class="row">
                                    <!-- Form Column -->
                                    <div class="col-lg-4 col-md-6 col-sm-6">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="alert alert-danger" role="alert">
                                                    We Are Trying Our Best <a href="#" class="alert-link">Pan Details Print By Only....</a>
                                                </div>
                                                <hr>
                                                <form method="post" id="pan_verification">
                                                    <div class="card-body">
                                                        <div class="col-md-10">
                                                            <div class="form-group">
                                                                <label class="form-group" for="pan_no">Enter PAN Number</label>
                                                            </div>
                                                            <input type="text" required class="form-control" name="pan_no" id="pan_no" placeholder="ENTER PAN NUMBER">
                                                        </div>
                                                    </div>
                                                    <div class="btn btn-outline-primary">
  <h5 class="text-success">Application Fee: <?php  
                                                        $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT price FROM pricing WHERE service_name='pan_no'"));  
                                                        echo "₹ " . $price['price'];
                                                    ?></h5>                                                    </div>
                                                    <div class="row row-sm mg-t-20">
                                                        <div class="col-lg">
                                                            <br>
                                                            <button type="submit" name="verify_pan" class="btn btn-success btn-block"><i class="fa fa-check-circle"></i> Verify PAN</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Result Column -->
                                    <div class="col-lg-8 col-md-6 col-sm-6">
                                        <div class="card" style="height: 380px; background-color: #c7f0d8;">
                                            <div class="card-body">
                                                <h6>Note: PAN details are provided only for verification purposes.</h6>
                                                <hr>
                                                <h6>Pan Number: <?php echo isset($pan_number) ? $pan_number : ''; ?></h6>
                                                <h6>Name: <?php echo isset($full_name) ? $full_name : ''; ?></h6>
                                                <h6>Date of Birth: <?php echo isset($dob) ? $dob : ''; ?></h6>
                                                <h6>Validity Status: <?php echo isset($valid_status) ? $valid_status : ''; ?></h6>
                                                <hr>
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- row -->
                            </div> <!-- container-fluid -->
                        </div> <!-- stat-content -->
                    </div> <!-- stat-widget -->
                </div> <!-- card -->
            </div>
        </div>
    </div>
</div>

<script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
<script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<script src="../template/ahkweb/assets/js/app.js"></script>
</body>
</html>


<?php include('footer.php'); ?>

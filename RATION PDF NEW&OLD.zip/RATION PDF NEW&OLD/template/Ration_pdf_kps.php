<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://jeremyfagis.github.io/dropify/dist/css/dropify.min.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
</head>
<body>

<?php
include('header.php');

if (isset($_POST['find'])) {
    $rt_no = mysqli_real_escape_string($ahk_conn, $_POST['rc_dl']);
    $rationtype = $_POST['rationtype'] === 'new' ? 1 : 0;

    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='rc_vehical_fee'"));
    $fee = $price['price'];

    $username = $udata['phone'];
    $wallet_amount = $udata['balance'];
    $debit_fee = $wallet_amount - $fee;

    if ($wallet_amount > $fee) {
        $api_key ="API_KEY_PASTE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )
        $url = "https://kycapizone.in/api/v2/ration/ration.php?api_key=$api_key&ration_no=$rt_no&type=$rationtype";

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        $result = json_decode($response, true);

        if (!$result['success']) {
            ?>
            <script>
                $(function(){
                    Swal.fire(
                        'Error!',
                        '<?php echo $result['response_message']; ?>',
                        'warning'
                    )
                });
                setTimeout(function(){
                    window.location.href='Ration_pdf_kps.php';
                }, 3000);
            </script>
            <?php
        } else {
            $bik_number = $result['result']['ration_no'];
            $state = $result['result']['state'];
            $pdf_file = $result['result']['pdf_file'];
            $full_response = mysqli_real_escape_string($ahk_conn, $response);

            mysqli_query($ahk_conn, "UPDATE users SET balance = balance - $fee WHERE phone = '$username'");

            $insert = mysqli_query($ahk_conn, "INSERT INTO rasn_print (application_no, username, rasan_no, state, response, status, message, fee, pdf) VALUES ('', '$username', '$bik_number', '$state', '$full_response', 'success', 'Valid Authentication', '$fee', '$pdf_file')");

            mysqli_query($ahk_conn, "INSERT INTO wallethistory (userid, amount, balance, purpose, status, type) VALUES ('$username', '$fee', '$debit_fee', 'Ration PDF', '1', 'Debit')");

            ?>
            <script>
                $(function(){
                    Swal.fire(
                        'Download Successful!',
                        'Ration No: <?php echo $bik_number; ?>',
                        'success'
                    )
                });
                setTimeout(() => {
                    window.location = 'Ration_Pdf_list.php';
                }, 3000);
            </script>
            <?php
        }
    } else {
        ?>
        <script>
            $(function(){
                Swal.fire(
                    'Oops!',
                    'Wallet Balance Insufficient! Please Recharge.',
                    'error'
                )
            });
            setTimeout(function(){
                window.location.href='wallet.php';
            }, 4000);
        </script>
        <?php
    }
}
?>

<!-- Page Form UI -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
            <div class="breadcrumb-title pe-3">Home</div>
            <div class="ps-3">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><i class="bx bx-home-alt"></i></li>
                    <li class="breadcrumb-item active">New APPLY</li>
                </ol>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="alert alert-dark">We Are Trying Our Best <a href="#" class="alert-link">RATION PDF / MERA RATION 2.0</a></div>

                            <form method="post" id="Job_print">
                                <div class="form-group">
                                    <label for="rc_dl">Enter Ration Number</label>
                                    <input type="text" required class="form-control" name="rc_dl" id="rc_dl" placeholder="Enter Rasan Number">
                                </div>

                                <div class="form-group">
                                    <label>Format Type</label>
                                    <select name="rationtype" required class="form-control">
                                        <option value="new">New Format Print</option>
                                        <option value="old">Old Format Print</option>
                                    </select>
                                </div>

                                <h5 class="text-warning">Application Fee:
                                    <?php
                                    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT price FROM pricing WHERE service_name='rc_vehical_fee'"));
                                    echo "₹" . $price['price'];
                                    ?>
                                </h5>

                                <div class="row">
                                    <div class="col">
                                        <button type="submit" name="find" class="btn btn-primary w-100"><i class="fa fa-check-circle"></i> Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div> <!-- card-body -->
                    </div> <!-- card -->
                </div> <!-- col -->
            </div> <!-- row -->
        </div> <!-- container -->
    </div> <!-- page-content -->
</div> <!-- page-wrapper -->

<script>
function removeSpaces(inputElement) {
    inputElement.value = inputElement.value.replace(/\s/g, '');
}
</script>

<?php include("footer.php");?>

<!-- Bootstrap & Plugins -->
<script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
<script src="../template/ahkweb/assets/js/jquery.min.js"></script>
<script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<script src="../template/ahkweb/assets/js/app.js"></script>
<script src="../template/ahkweb/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="../template/ahkweb/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DataTable();
});
</script>

</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
</head>
<?php
include('header.php');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='genrate_eid_price' "));
    $fee = $price['price'];
    $username = $udata['phone'];
    $wallet_amount = $udata['balance'];
    $debit_fee = $wallet_amount - $fee;

    if ($wallet_amount > $fee) {   
        $api_key="apikey_paste";  // Api Key Paste Here || buy from apizone.online
        $eid_no = $_POST['eid_no'];
        $url = "https://kycapizone.in/api/v2/generated_eid/eid_v.php?eid_no=$eid_no&api_key=$api_key";
    
$curl = curl_init();
curl_setopt_array($curl, array( 
  CURLOPT_URL => $url,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
));

 $response = curl_exec($curl);
 curl_close($curl);
// Execute cURL session
$resdata = json_decode($response, true);
// Check for cURL errors
$status=$resdata['status'];
$message=$resdata['message'];
// $name=$resdata['name'];
$aadhaar=$resdata['aadhaar'];
$enrillment=$resdata['eid_no'];
$error=$resdata['error'];
if ($error) {
            ?>
            <script>
                $(function(){
                    Swal.fire(
                        '<?php echo $error; ?>',
                        'Contact ADMIN',
                        'warning'
                    )
                });
                window.setTimeout(function(){
                    window.location.href='';
                },4000);
            </script>
            <?php
            } else if ($aadhaar != "") {
            $debit = mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$username'");
            date_default_timezone_set("Asia/Kolkata");
            $time_hkb = date('d/m/Y g:i:s');
            $insert = mysqli_query($ahk_conn, "INSERT INTO `matching_dublicate_hkb`(`aadhaar_no`, `status`, `fee`, `generated_eid`, `date`, `userid`,`message`) VALUES ('$aadhaar','$status','$fee', '$enrillment', '$time_hkb','$username','HKB')");      
            if (!$insert) {
                die('Error: ' . mysqli_error($ahk_conn));
            }
            
            $updatehistory = mysqli_query($ahk_conn,"INSERT INTO `wallethistory`(`userid`, `amount`, `balance`, `purpose`, `status`, `type`) VALUES ('$username','$fee','$debit_fee','Eid to aadhar','1','Debit')");
           if ($insert) {
                // Fetching fullname from tbluser
   $legand_fetch = mysqli_fetch_array(mysqli_query($ahk_conn,"SELECT * FROM `users` WHERE `phone`='$username'"));
   $fullname = $legand_fetch['name'];

    $sender = "$sender_number";
    $number = 91 . $username;
                  
    // Send Message Admin Api To User  
    $usermsg = urlencode ("Thank You 🎉 Dear *$fullname* 🎉 Your data *Generate Eid To Aadhar No*

_Your Data Applicant Aadhar No : *$aadhaar* ");

    $sms_url = "https://$whatsapp_url/send-message?api_key={$whatsapp_kay}&sender={$sender}&number={$number}&message=$usermsg";
    $response = file_get_contents("$sms_url");                
               
                ?>
                <script>
                    $(function(){
                        Swal.fire(
                            'Aadhaar NO Found : <?php echo $aadhaar;?>',
                            'For This EID : <?php echo $enrillment; ?>!',
                            'success'
                        )
                    })
                    setTimeout(() => {
                        window.location='Generate_eid_list.php';    // redirect to print list 
                    }, 6000);
                </script>
                <?php
            }
        }


} else {
        ?>
        <script>
            $(function(){
                Swal.fire(
                    'Opps',
                    'Wallet Balance Insufficient! Please Recharge ',
                    'error'
                )
            });
            window.setTimeout(function(){
                window.location.href='wallet.php';      // redirect to your wallet 
            },4000);
        </script>
        <?php
    }
}
?>

<body>

<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
			
<div class="content-wrap">
    <div class="main">
        <div class="col-md-12">
            <div class="container-fluid">
            </div>
            </div>
                                <div class="row">
                                    <div class="col-lg-4 col-md-6 col-sm-6">
                                        <div class="card">
                                            <div class="card-body">
                            <div class="alert alert-dark" role="alert">
                                We Are Trying Our Best
                                <a href="#" class="alert-link">EID TO AADHAR NUMBER IS NOW LIVE</a>
                            </div>
       
         <form name="" action="" method="POST" >
            <div class="form-group">
                <label for="eid_no">Enrollment Number:</label>
                <input type="text" class="form-control" id="eid_no" name="eid_no" value="" minlength="28" maxlength="28" placeholder="2017600030279520160901165949" required>
                <p id="verificationMessage"></p>


 <div class="col-12 ml-2">
		    	<h5 class="text-success ">Application Fee: <?php  
		    		$price = mysqli_fetch_assoc(mysqli_query($ahk_conn,"SELECT price FROM pricing WHERE service_name='genrate_eid_price'")); 
		    		echo "₹" .$price['price'];
		    		?></h5>
            </div>
            <button type="submit" name="send_otp" class="btn btn-primary">Submit</button>
              </center>
                                </div>
                            </form>
                        </div>

    </div>

 <!--end page wrapper -->
<?php 
include('footer.php');
?>
<!-- Bootstrap JS -->
<script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
<!--plugins-->
<script src="../template/ahkweb/assets/js/jquery.min.js"></script>
<script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<script src="../template/ahkweb/assets/plugins/chartjs/chart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/sparkline-charts/jquery.sparkline.min.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/excanvas.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/jquery.knob.js"></script>
<script>
$(function() {
    $(".knob").knob();
});
</script>
<script src="../template/ahkweb/assets/js/index.js"></script>
<!--app JS-->
<script src="../template/ahkweb/assets/js/app.js"></script>
<!-- datatable -->
<script src="../template/ahkweb/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="../template/ahkweb/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	
	<script>
		$(document).ready(function() {
			var table = $('#example2').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'pdf', 'print']
			} );
		 
			table.buttons().container()
				.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
		} );
	</script>
	
</body>



</html>
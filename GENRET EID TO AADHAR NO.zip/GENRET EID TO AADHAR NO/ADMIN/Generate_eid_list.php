<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/Generate_eid_list.php');

?>

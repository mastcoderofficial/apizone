<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<?php
include('header.php');

if (isset($_POST['A2A']) && $_POST['A2A'] == "Apizone") {
    $dl = mysqli_real_escape_string($ahk_conn, $_POST['dl']);
    $type = mysqli_real_escape_string($ahk_conn, $_POST['type']);
    $application_no = "S4P_" . rand(100000, 999999);

    $apiKey = "API_KEY_PASTEE"; //  // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )

    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='dl_gf_instant'"));
    $fee = $price['price'];
    $username = $udata['phone'];
    $wallet = $udata['balance'];

    if ($wallet > $fee) {
        $debit_fee = $wallet - $fee;

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://kycapizone.in/api/v2/dl/DL-chip.php?dl_number=$dl&dltype=$type&api_key=$apiKey",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        $resdata = json_decode($response, true);

        if (!$resdata['success']) {
            ?>
            <script>
                $(function () {
                    Swal.fire(
                        'Failed!',
                        '<?php echo $resdata['response_message'] ?? "Unknown Error"; ?>',
                        'error'
                    )
                });
                window.setTimeout(function () {
                    window.location.href = '';
                }, 4000);
            </script>
            <?php
        } elseif (empty($resdata['result']['pdf_file'])) {
            ?>
            <script>
                $(function () {
                    Swal.fire(
                        'No PDF!',
                        'PDF file not returned. Contact Admin.',
                        'warning'
                    )
                });
                window.setTimeout(function () {
                    window.location.href = '';
                }, 5000);
            </script>
            <?php
        } else {
            $name = $resdata['result']['fullname'] ?? '';
            $dob = $resdata['result']['dob'] ?? '';
            $dlNumber = $resdata['result']['dl_number'] ?? '';
            $pdf = $resdata['result']['pdf_file'] ?? '';

            $debit = mysqli_query($ahk_conn, "UPDATE `users` SET balance='$debit_fee' WHERE phone='$username'");
            if ($debit) {
                $insert = mysqli_query($ahk_conn, "INSERT INTO dlprint (application_no, username, dl_no, dob, status, fee, pdf) VALUES ('$application_no', '$username', '$dlNumber', '$dob', 'success', '$fee', '$pdf')");
                if ($insert) {
                    ?>
                    <script>
                        $(function () {
                            Swal.fire(
                                'DL: <?php echo $dl; ?> downloaded',
                                'Application: <?php echo $application_no; ?> | File Generated',
                                'success'
                            )
                        });
                        setTimeout(() => {
                            window.location = 'Dl_pdf_list.php';
                        }, 1200);
                    </script>
                    <?php
                }
            }
        }
    } else {
        ?>
        <script>
            $(function () {
                Swal.fire(
                    'Oops!',
                    'Wallet Balance Insufficient! Please Recharge.',
                    'error'
                )
            });
            setTimeout(function () {
                window.location.href = 'wallet.php';
            }, 3000);
        </script>
        <?php
    }
}
?>
<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
									<div class="card border-top border-0 border-4 border-primary">
							<div class="card-body p-5">
								<div class="card-title d-flex align-items-center">
									<div><i class="bx bxs-id-card me-1 font-22 text-primary"></i>
									</div>
									<h5 class="mb-0 text-primary">Enter DL Number Details</h5>
								</div>
								<hr>
                <form name="" action="" method="post" id="dlprint">
                    <input type="hidden" name="A2A" value="Apizone" />
                    <div class="mb-3">
                        <label class="form-label" for="dl">DL Number</label>
                        <input type="text" class="form-control" name="dl" id="dl" placeholder="Enter DL Number" required oninput="this.value = this.value.replace(/\s/g, '')" />
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="type">Card Format<span class="text-danger">*</span></label>
                        <select name="type" id="type" class="form-control" required>
                            <option value="1">Without Chip</option>
                            <option value="2">Chip</option>
                            <option value="3">Without Chip (New)</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Submit</button>
                                                                  </center>
                                                            </div>
                                                        </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>

<!--end page wrapper -->
<?php 
include('footer.php');
?>
<!-- Bootstrap JS -->
<script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
<!--plugins-->
<script src="../template/ahkweb/assets/js/jquery.min.js"></script>
<script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<script src="../template/ahkweb/assets/plugins/chartjs/chart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/sparkline-charts/jquery.sparkline.min.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/excanvas.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/jquery.knob.js"></script>
<script>
$(function() {
    $(".knob").knob();
});
</script>
<script src="../template/ahkweb/assets/js/index.js"></script>
<!--app JS-->
<script src="../template/ahkweb/assets/js/app.js"></script>
<!-- datatable -->
<script src="../template/ahkweb/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="../template/ahkweb/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	
	<script>
		$(document).ready(function() {
			var table = $('#example2').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'pdf', 'print']
			} );
		 
			table.buttons().container()
				.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
		} );
	</script>
	
</body>



</html>

<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/uid_to_ration.php');

?>
<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/UidRation_List.php');

?>
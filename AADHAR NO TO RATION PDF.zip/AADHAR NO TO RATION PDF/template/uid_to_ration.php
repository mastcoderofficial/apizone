<?php
include('header.php');

$appliedby = $udata['phone'];
$wallet_amount = $udata['balance'];
$price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='rc_vehical_fee'"));
$fee = $price['price'];

if ($_POST['aadharNumber']) {
    $aadharNumber = mysqli_real_escape_string($ahk_conn, $_POST['aadharNumber']);
    $rationtype = $_POST['rationtype'] === 'new' ? 1 : 0;
    $debit_fee = $wallet_amount - $fee;

    if ($wallet_amount >= $fee) {
        $api_key = "APIKEYPASTEEE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )
        $url = "https://kycapizone.in/api/v2/ration/uid_to_ration.php?api_key=$api_key&aadhaar_no=$aadharNumber&type=$rationtype";

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CUSTOMREQUEST => "GET",
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        $resdata = json_decode($response, true);

        if (!$resdata['success']) {
            ?>
            <script>
                $(function () {
                    Swal.fire(
                        '<?= $resdata['response_message']; ?>',
                        'Contact Admin',
                        'error'
                    );
                });
                setTimeout(() => {
                    window.location = '';
                }, 5000);
            </script>
            <?php
        } else {
            date_default_timezone_set('Asia/Kolkata');
            $timehkb = date("Y-m-d H:i:s");

            $aadhar = $resdata['result']['aadhaar_no'];
            $pdf = $resdata['result']['pdf_file'];
            $ration_no = $resdata['result']['ration_no'];
            $state = $resdata['result']['state'];

            $debit = mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$appliedby'");
            $updatehistory = mysqli_query($ahk_conn, "INSERT INTO wallethistory(userid, amount, balance, purpose, status, type) VALUES ('$appliedby', '$fee', '$debit_fee', 'AADHAR TO RATION PDF', '1', 'Debit')");

            if ($debit) {
                $insert = mysqli_query($ahk_conn, "INSERT INTO rationPdf_Uid(name, aadhaar, pdf, username, date) VALUES ('$ration_no', '$aadhar', '$pdf', '$appliedby', '$timehkb')");
                if ($insert) {
                    ?>
                    <script>
                        $(function () {
                            Swal.fire(
                                'Ration PDF Download Success',
                                'Successfully fetched',
                                'success'
                            );
                        });
                        setTimeout(() => {
                            window.location = 'UidRation_List.php';
                        }, 5000);
                    </script>
                    <?php
                } else {
                    ?>
                    <script>
                        $(function () {
                            Swal.fire(
                                'DATA INSERT ERROR',
                                'Database error!',
                                'warning'
                            );
                        });
                        setTimeout(() => {
                            window.location = '#';
                        }, 1500);
                    </script>
                    <?php
                }
            } else {
                ?>
                <script>
                    $(function () {
                        Swal.fire(
                            'Balance Debit Error',
                            'Something went wrong!',
                            'error'
                        );
                    });
                    setTimeout(() => {
                        window.location = '#';
                    }, 1500);
                </script>
                <?php
            }
        }
    } else {
        ?>
        <script>
            $(function () {
                Swal.fire(
                    'Wallet Balance is Low!',
                    'Please Recharge Now!',
                    'error'
                );
            });
            setTimeout(() => {
                window.location = 'wallet.php';
            }, 2000);
        </script>
        <?php
    }
}
?>


<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Home</div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">New APPLY</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<button type="button" class="btn btn-primary">Settings</button>
							<button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">	<span class="visually-hidden">Toggle Dropdown</span>
							</button>
							<div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end">	<a class="dropdown-item" href="javascript:;">Action</a>
								<a class="dropdown-item" href="javascript:;">Another action</a>
								<a class="dropdown-item" href="javascript:;">Something else here</a>
								<div class="dropdown-divider"></div>	<a class="dropdown-item" href="javascript:;">Separated link</a>
							</div>
						</div>
					</div>
				</div>
<div class="content-wrap">
    <div class="main">
        <div class="col-md-12">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="alert alert-dark" role="alert">
                                    We Are Trying Our Best
                                    <a href="#" class="alert-link"> RATION  PDF / UID TO RATION</a>
                                </div>
                               	<form action="" method="POST" class="row g-3">
                                <div class="card-body">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Aadhar Number.</label>
                                              	<input name="aadharNumber" type="text" id="aadharNumber" maxlength="12" placeholder="Enter 12 Digit Aadhar Number" class="form-control" >
                                                  </div>
                                                   </select>
                                                <hr>
                                             <div class="form-group col-md-10"> 
                                             
										<label for="inputFirstName" class="form-label">Format Type</label>
										<select name="rationtype"  required class="form-control" >
										    <option value="1">New Format Print</option>
										     <option value="0">Old Format  Print</option>
										</select>
                                       <input class="form-control " id="text" name="" value="<?php  
										echo "Charge : ₹ " .$fee;
										?>" placeholder="Rc. No." type="text"  required readonly>
                                       <hr>
                                     
                                    </div>
                                </div>
							<div class="form-actions">
                            <div class="text-left">
                            <button class="form-control btn btn-success" name="submit" id="submit"><i class="fa fa-check-circle"></i> Submit</button>
						 </div>
                                    </div>
                                    
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function removeSpaces(inputElement) {
    inputElement.value = inputElement.value.replace(/\s/g, '');
}
</script>
<?php include("footer.php");?>
<!-- Bootstrap JS -->
<script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
<!--plugins-->
<script src="../template/ahkweb/assets/js/jquery.min.js"></script>
<script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<script src="../template/ahkweb/assets/plugins/chartjs/chart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/sparkline-charts/jquery.sparkline.min.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/excanvas.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/jquery.knob.js"></script>
<script>
$(function() {
    $(".knob").knob();
});
</script>
<script src="../template/ahkweb/assets/js/index.js"></script>
<!--app JS-->
<script src="../template/ahkweb/assets/js/app.js"></script>
<!-- datatable -->
<script src="../template/ahkweb/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="../template/ahkweb/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	
	<script>
		$(document).ready(function() {
			var table = $('#example2').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'pdf', 'print']
			} );
		 
			table.buttons().container()
				.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
		} );
	</script>
	
</body>



</html>
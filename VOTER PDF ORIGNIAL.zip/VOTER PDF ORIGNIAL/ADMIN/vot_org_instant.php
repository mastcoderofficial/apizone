<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/vot_org_instant.php');
?>
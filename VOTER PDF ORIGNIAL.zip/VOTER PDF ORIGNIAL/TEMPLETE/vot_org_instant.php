<?php
include('header.php');

$message = "";
$epic_no = "";
$otp = "";
$pdf_url = "";
$voter_details = [];
$step = 1; // Default step = enter EPIC and send OTP
        $api_key ="APIKEYPASTTEEE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['step']) && $_POST['step'] == "send_otp") {
        // Step 1: Send OTP
        $epic_no = mysqli_real_escape_string($ahk_conn, $_POST['epic_no']);
        $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT price FROM pricing WHERE service_name='voter_original_fee'"));
        $fee = $price['price'];
        $old_balance = $udata['balance'];
        $username = $udata['phone'];
        $appliedby = $udata['phone'];

        if ($old_balance >= $fee) {
            $url = "https://kycapizone.in/api/v2/voter/voter_download_send_otp.php?api_key=$api_key&epic_no=$epic_no";
            $response = file_get_contents($url);
            $result = json_decode($response, true);

            if ($result['success'] === true && $result['response_code'] == 200) {
                $message = $result['response_message'];
                $step = 2; // Go to OTP input step
            } else {
                $message = "Error sending OTP: " . ($result['response_message'] ?? 'Unknown error');
            }
        } else {
            $message = "Wallet Balance is Low! Please Recharge Now!";
        }
    } elseif (isset($_POST['step']) && $_POST['step'] == "download_pdf") {
        // Step 2: Download PDF with EPIC and OTP
        $epic_no = mysqli_real_escape_string($ahk_conn, $_POST['epic_no']);
        $otp = mysqli_real_escape_string($ahk_conn, $_POST['otp']);
        $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT price FROM pricing WHERE service_name='voter_original_fee'"));
        $fee = $price['price'];
        $old_balance = $udata['balance'];
        $username = $udata['phone'];
        $appliedby = $udata['phone'];

        if ($old_balance >= $fee) {
            $payload = json_encode(['epic_no' => $epic_no, 'otp' => $otp]);
            $data = base64_encode($payload);

            $url = "https://kycapizone.in/api/v2/voter/voter_download.php?data=$data&api_key=$api_key";
            $response = file_get_contents($url);
            $result = json_decode($response, true);

            if ($result['success'] === true && $result['response_code'] == 200) {
                // Debit balance and log
                $new_balance = $old_balance - $fee;
                $debit = mysqli_query($ahk_conn, "UPDATE users SET balance=$new_balance WHERE phone='$appliedby'");
                $updatehistory = mysqli_query($ahk_conn, "INSERT INTO wallethistory (userid, amount, old_balance, balance, purpose, status, type) VALUES ('$appliedby', '$fee', '$old_balance', '$new_balance', 'VOTER PDF DOWNLOAD', 'Success', 'Debit')");

                if ($debit) {
                    $refId = $result['result']['refId'];
                    $pdf_url = $result['result']['pdf_file'];
                    $voter_details = $result['result']['details'];

                    // Insert record into voter_pdf_download table
                    $insert = mysqli_query($ahk_conn, "INSERT INTO voter_pdf_download (username, epic_no, ref_id, pdf_url, response) VALUES ('$username', '$epic_no', '$refId', '$pdf_url', '" . mysqli_real_escape_string($ahk_conn, $response) . "')");

                    $message = "PDF Download Successful.";
                    $step = 3; // Show details and link
                } else {
                    $message = "Balance debited but error saving data.";
                    $step = 2;
                }
            } else {
                $message = "Failed to download PDF: " . ($result['response_message'] ?? 'Unknown error');
                $step = 2;
            }
        } else {
            $message = "Wallet Balance is Low! Please Recharge Now!";
            $step = 1;
        }
    }
}
?>

     	<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Home </div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">New APPLY</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<button type="button" class="btn btn-primary">Settings</button>
							<button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">	<span class="visually-hidden">Toggle Dropdown</span>
							</button>
							<div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end">	<a class="dropdown-item" href="javascript:;">Action</a>
								<a class="dropdown-item" href="javascript:;">Another action</a>
								<a class="dropdown-item" href="javascript:;">Something else here</a>
								<div class="dropdown-divider"></div>	<a class="dropdown-item" href="javascript:;">Separated link</a>
							</div>
						</div>
					</div>
				</div>
<head>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <style>
        .hidden {
            display: none;
        }
    </style>
</head>
<body>

    <div class="content-wrap">
      <div class="container-fluid pt-4 px-4">
				<!--end breadcrumb-->
        <div class="main">
            <div class="col-md-12">
                <div class="main-content">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-4">
                        <div class="card card-default ">
                            <div class="card-header bg-warning">
                                <div class="card-title">
                                    <h3><strong>VOTER ORIGINAL PDF DOWNLOAD !</strong></h3>
                                </div>
                            </div>
                            <br>
                        </div>
                                            <hr>
                                            <?php if ($message) : ?>
                                                <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
                                            <?php endif; ?>

                                            <?php if ($step == 1): ?>
                                            <form action="" method="POST" class="row g-3">
                                                <div class="col-md-12">
                                                    <label for="epic_no" class="form-label">Enter Voter EPIC Number</label>
                                                    <input name="epic_no" id="epic_no" type="text" placeholder="Enter EPIC Number" class="form-control" required value="<?php echo htmlspecialchars($epic_no); ?>">
                                                </div>
                                                <input type="hidden" name="step" value="send_otp">
                                                <div class="col-12 mt-3">
                                                    <h5 class="btn btn-outline-primary">Application Fee: ₹<?php echo $price['price'] ?? '0'; ?></h5>
                                                </div>
                                                <div class="col-12 mt-3">
                                                    <button type="submit" class="btn btn-primary btn-block">Send OTP</button>
                                                </div>
                                            </form>

                                            <?php elseif ($step == 2): ?>
                                            <form action="" method="POST" class="row g-3">
                                                <div class="col-md-12">
                                                    <label for="epic_no" class="form-label">Voter EPIC Number</label>
                                                    <input name="epic_no" id="epic_no" type="text" class="form-control" readonly value="<?php echo htmlspecialchars($epic_no); ?>">
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="otp" class="form-label">Enter OTP</label>
                                                    <input name="otp" id="otp" type="text" placeholder="Enter OTP" class="form-control" required value="<?php echo htmlspecialchars($otp); ?>">
                                                </div>
                                                <input type="hidden" name="step" value="download_pdf">
                                                <div class="col-12 mt-3">
                                                    <h5 class="btn btn-outline-primary">Application Fee: ₹<?php echo $price['price'] ?? '0'; ?></h5>
                                                </div>
                                                <div class="col-12 mt-3">
                                                    <button type="submit" class="btn btn-success btn-block">Download PDF</button>
                                                </div>
                                            </form>

                                            <?php elseif ($step == 3): ?>
                                            <div class="card" style="background-color: #c7f0d8; padding: 15px;">
                                                <h6>Voter Details</h6>
                                                <hr>
                                                <p><strong>Name:</strong> <?php echo htmlspecialchars($voter_details['name'] ?? '-'); ?></p>
                                                <p><strong>Father's Name:</strong> <?php echo htmlspecialchars($voter_details['father_name'] ?? '-'); ?></p>
                                                <p><strong>Gender:</strong> <?php echo htmlspecialchars($voter_details['gender'] ?? '-'); ?></p>
                                                <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($voter_details['dob'] ?? '-'); ?></p>
                                                <p><strong>State:</strong> <?php echo htmlspecialchars($voter_details['state'] ?? '-'); ?></p>
                                                <hr>
                                                <a href="<?php echo $pdf_url; ?>" download="voter.pdf" class="btn btn-primary">Download Voter PDF</a>
                                                <br><br>
                                                <a href="" class="btn btn-dark">Start New Download</a>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                </div>
                            </div>

                        </div> <!-- container-fluid -->
                    </div> <!-- stat-text -->
                </div> <!-- stat-content -->
            </div> <!-- stat-widget-two -->
        </div> <!-- card -->
    </div> <!-- col-lg-12 -->
</div> <!-- main-container -->

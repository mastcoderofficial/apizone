<?php 
// Database  Details  
$hostname = "localhost";
$username = "u414008981_new_allinone";
$password = "8n!7s1zSF";
$database ="u414008981_new_allinone";
$ahk_conn = mysqli_connect($hostname,$username,$password,$database);

if(!$ahk_conn){
    include('links.php');
   ?>
   <script>
    $(function(){
        Swal.fire(
            'Opps',
            'Dadatabase Connection Failed',
            'error'
        )
    })
   </script>
   <?php
}
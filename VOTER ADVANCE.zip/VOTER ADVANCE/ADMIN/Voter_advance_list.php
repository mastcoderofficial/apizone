<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/Voter_advance_list.php');
?>
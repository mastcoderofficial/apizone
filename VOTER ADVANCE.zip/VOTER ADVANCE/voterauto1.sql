-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 05, 2024 at 11:04 PM
-- Server version: 8.0.36
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dostixyz_team_dost`
--

-- --------------------------------------------------------

--
-- Table structure for table `voterauto1`
--

CREATE TABLE `voterauto1` (
  `voterautoid` int NOT NULL,
  `votername` varchar(250) DEFAULT NULL,
  `aadharname` varchar(250) DEFAULT NULL,
  `namelocal` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `dob` varchar(50) DEFAULT NULL,
  `dobinlocal` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `genderlocal` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `sexlocal` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `spousename` varchar(50) DEFAULT NULL,
  `spousenamelocal` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `fathername` varchar(150) DEFAULT NULL,
  `fatheraadharname` varchar(250) DEFAULT NULL,
  `fathernamelocal` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `epicno` varchar(50) DEFAULT NULL,
  `policestation` varchar(150) DEFAULT NULL,
  `tahshil` varchar(150) DEFAULT NULL,
  `assconnonm` varchar(150) DEFAULT NULL,
  `assconnonmlocal` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `partno` varchar(50) DEFAULT NULL,
  `partname` varchar(250) DEFAULT NULL,
  `partnamelocal` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `locallanguage` varchar(50) DEFAULT NULL,
  `fulladdress` varchar(250) DEFAULT NULL,
  `localaddress` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `pata` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `kaname` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `sign` varchar(250) DEFAULT NULL,
  `signlocal` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `assconnameno` varchar(250) DEFAULT NULL,
  `assconnamenolocal` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `partnoandname` varchar(250) DEFAULT NULL,
  `partnoandnamelocal` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `imagepathoriginal` longtext,
  `status` varchar(50) DEFAULT NULL,
  `updatestatusdatetime` datetime DEFAULT NULL,
  `updateuserid` int DEFAULT NULL,
  `srno` int DEFAULT NULL,
  `createdatetime` datetime DEFAULT NULL,
  `userid` varchar(200) DEFAULT NULL,
  `payment_status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `voterauto1`
--
ALTER TABLE `voterauto1`
  ADD PRIMARY KEY (`voterautoid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `voterauto1`
--
ALTER TABLE `voterauto1`
  MODIFY `voterautoid` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/header.php');

$resdata = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['uan_no']) && !empty($_POST['dob'])) {
    $uan_no = trim($_POST['uan_no']);
    $dob = trim($_POST['dob']);
    $appliedby = $udata['phone'];

    // Wallet Fee Check
    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='UAN_to_Aadhaar_Fee'"));
    $fee = $price['price'];
    $debit_fee = $udata['balance'] - $fee;

    if ($udata['balance'] >= $fee) {
        $api_zone = "API_KEY_PASTE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )
        $url = "http://kycapizone.in/api/v2/aayushman/get_aadhaar_by_uan.php?api_key=$api_zone&uan_no=$uan_no&dob=$dob";

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CUSTOMREQUEST => 'GET',
        ]);
        $response = curl_exec($curl);
        curl_close($curl);

        $apiResult = json_decode($response, true);

        if ($apiResult && $apiResult['success'] === true && $apiResult['response_code'] === '100') {
            $resdata = $apiResult['result'];
            // Wallet deduction and logging
            mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$appliedby'");
            mysqli_query($ahk_conn, "INSERT INTO wallethistory(userid, amount, balance, purpose, status, type) VALUES ('$appliedby', '$fee', '$debit_fee', 'UAN to Aadhaar Lookup', '1', 'Debit')");
        } else {
            echo "<script>Swal.fire('Failed', 'API Error: " . htmlspecialchars($apiResult['response_message'] ?? 'Unknown error') . "', 'error');</script>";
        }
    } else {
        echo "<script>Swal.fire('Low Balance', 'Please recharge your wallet!', 'warning');</script>";
    }
}
?>

<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
    <div class="row">
      <!-- Form Panel -->
      <div class="col-md-4">
        <form method="POST" class="card p-3 shadow">
          <h5 class="mb-3 text-danger">UAN ➜ Aadhaar Lookup</h5>
          <div class="form-group mb-2">
            <label>UAN Number</label>
            <input type="text" name="uan_no" required class="form-control" placeholder="Enter UAN Number">
          </div>
          <div class="form-group mb-2">
            <label>Date of Birth (YYYY-MM-DD)</label>
            <input type="date" name="dob" required class="form-control">
          </div>
          <div class="form-group mb-3">
            <label>Fee</label>
            <input type="text" class="form-control" value="₹ <?= $fee ?>" readonly>
          </div>
          <button type="submit" class="btn btn-primary w-100"><i class="fa fa-search"></i> Submit</button>
        </form>
      </div>

     <!-- Result Panel -->
      <?php if (!empty($resdata['result'])): $r = $resdata['result']; ?>
      <div class="col-md-8">
        <div class="card p-3 shadow">
          <h5>✅ Aadhaar Details from UAN</h5>
          <table class="table table-bordered table-striped">
            <tr><th>Name</th><td><?= htmlspecialchars($r['name']) ?></td></tr>
            <tr><th>Aadhaar No</th><td><?= htmlspecialchars($r['aadhaar_no']) ?></td></tr>
            <tr><th>UAN No</th><td><?= htmlspecialchars($r['uan_no']) ?></td></tr>
            <tr><th>DOB</th><td><?= htmlspecialchars($r['dob']) ?></td></tr>
            <tr><th>Gender</th><td><?= htmlspecialchars($r['gender']) ?></td></tr>
            <tr><th>Father's Name</th><td><?= htmlspecialchars($r['father_name']) ?></td></tr>
            <tr><th>Husband's Name</th><td><?= htmlspecialchars($r['husband_name']) ?></td></tr>
            <tr><th>Mobile</th><td><?= htmlspecialchars($r['mobile']) ?></td></tr>
            <tr><th>Address</th><td><?= htmlspecialchars($r['address']) ?></td></tr>
          </table>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include('footer.php'); ?>
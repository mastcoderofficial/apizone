<?php
include('header.php');
?>
 <?php
  $price = mysqli_fetch_assoc(mysqli_query($ahk_conn,"SELECT * FROM pricing WHERE service_name='voter_manual_hkb' "));
                  $fee = $price['price'];
$balance = $udata['balance'];
if ($balance < $fee+1) {?>
    <script>
                    $(function(){
                        Swal.fire(
                            'Wallet amount is Low Please Maintain Wallet Above From Fee ',
                            '',
                            'error'
                        )
                    })
                    setTimeout(() => {
                        window.location='wallet.php';
                    }, 1000);
                </script>
<?php }?>
     	<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Home </div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">New APPLY</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<button type="button" class="btn btn-primary">Settings</button>
							<button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">	<span class="visually-hidden">Toggle Dropdown</span>
							</button>
							<div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end">	<a class="dropdown-item" href="javascript:;">Action</a>
								<a class="dropdown-item" href="javascript:;">Another action</a>
								<a class="dropdown-item" href="javascript:;">Something else here</a>
								<div class="dropdown-divider"></div>	<a class="dropdown-item" href="javascript:;">Separated link</a>
							</div>
						</div>
					</div>
				</div>
				<!--end breadcrumb-->
				<div class="row">
					<div class="col-xl-10 mx-auto">
						<h6 class="mb-0 text-uppercase">Voter Advance</h6>
						<hr/>
						<div class="card border-top border-0 border-4 border-primary">
							<div class="card-body p-5">
								<div class="card-title d-flex align-items-center">
									<div><i class="bx bxs-id-card me-1 font-22 text-primary"></i>
									</div>
									<h5 class="mb-0 text-primary">Enter Voter Details</h5>
								</div>
								<hr>
	<script type="text/javascript">
     function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah1')
                        .attr('value', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>
                             	<form method="post" name="form" autocomplete="off"  enctype="multipart/form-data" action="voter_info_hkb.php" style="width:100%">
									   <div class="row dgnform">
								       <div class="col-md-13 col-sm-12 col-xs-12">
											<div class="row">
                                                <div class="col-sm-4 col-xs-20">
                                                    <label>Epic No.</label>
                                                    <div class="form-group">
                                                        <input class="form-control" name="epicno"  type="text" placeholder="Enter Epic No" required="">
                                                    </div>
                                                </div>
                                              </div>
                                              
                                                <style>
                                                		.image-preview__image{
                                                  			max-width:110px;
                                                  			min-height: 110px;
                                                		}
                                                			.image-preview{
                                                        			width: 110px;
                                                        			min-height: 110px;
                                                        			border: 2px solid #ddd;
                                                        			margin-top: 5px;

                                                        			display: flex;
                                                        			align-items: center;
                                                        			justify-content: center;
                                                        			font-weight: bold;
                                                        			color: #ccc;
                                                			}
                                                		.image-preview__image{
                                                        		//display: none;
                                                        		width: 100%;
                                                		}
                                        		</style>
                                        	
						
                                                    <div class="row">
                                                       <div class="col-sm-5 col-xs-20">
                                                    	</div>
						                              </div>
						                              <br>
                                                   <label>Upload Photo </label>
                                                        <input type='file' id="filedata" name="" onchange="readURL(this);" />
                                                        <input class="form-control" id="blah1" name="filedata" type="hidden" value="" require>
											     	</div>
							                   	<br><br>
										        <div class="row" style=" margin-top:25px;">
                                            <div class="col-12 ml-4">
								          	<h5 class="text-warning ">Application Fee: <?php  
								          		$price = mysqli_fetch_assoc(mysqli_query($ahk_conn,"SELECT price FROM pricing WHERE service_name='voter_manual_hkb'")); 
								          		echo "₹" .$price['price'];
								          		?></h5>
								          		
								          	</div>
											    	<label>&nbsp;</label>
											     	<div class="form-group">              
												   <input type="submit" id="submit" name="submit" class="btn btn-success btn-block " style="" value="Submit" </input>
                                                	<div id="result"></div>
                                               <br><br>


	
	<script>
	
	$(document).ready(
    function(){
        $('input:file').change(
            function(){
                if ($(this).val()) {
                    $('input:submit').attr('disabled',false); 
                } 
            }
            );
    });
	</script> 
	</div> 
	
                                            <input type="hidden" id="deviceport" />
                                       
						
	<!--end page wrapper -->
		<?php 
		include('footer.php');
		?>
	<!-- Bootstrap JS -->
	

	<script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
	<!--plugins-->
	<!-- <script src="../template/ahkweb/assets/js/jquery.min.js"></script> -->
	<script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!--app JS-->
	<script src="../template/ahkweb/assets/js/app.js"></script>
</body>

<script>
	$(document).ready(function() {
	
	$('#eid').inputmask();
	$('#date').inputmask();
	$('#pan_no').inputmask();
	$('#timea').inputmask("hh:mm:ss", {
        placeholder: "00:00:00", 
        insertMode: false, 
        showMaskOnHover: false,
        hourFormat: 12
      });
	});
</script>
</html>
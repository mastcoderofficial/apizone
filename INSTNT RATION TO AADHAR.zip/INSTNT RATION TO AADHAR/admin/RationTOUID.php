<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/header.php');

if (isset($_POST['rationNumber'])) {
    $rationNumber = $_POST['rationNumber'] ?? null;

    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='ration2_uid_findfee'"));
    $fee = $price['price'];
    $username = $udata['phone'];
    $wallet = $udata['balance'];

    if ($wallet >= $fee) {
        $debit_fee = $wallet - $fee;

        $api_key ="APIKEYYPASTEEE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )
        $url = "https://kycapizone.in/api/v2/ration/ration_to_uid.php?api_key=$api_key&ration_no=$rationNumber";

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_TIMEOUT => 30,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
        ]);

        $response = curl_exec($curl);
        curl_close($curl);
        $resdata = json_decode($response, true);

        if (!$resdata['success']) {
            ?>
            <script>
                $(function(){
                    Swal.fire(
                        '<?= $resdata['response_message'] ?? "Error" ?>',
                        'Please Try Correct Details',
                        'warning'
                    )
                });
                window.setTimeout(function(){
                    window.location.href='#';
                }, 20000);
            </script>
            <?php
        } elseif ($resdata['response_code'] == "100" && $resdata['success']) {
            // Deduct wallet
            mysqli_query($ahk_conn, "UPDATE `users` SET balance='$debit_fee' WHERE phone='$username'");
            date_default_timezone_set('Asia/Kolkata');
            $timestamp = date("Y-m-d H:i:s");

            // Log transaction
            mysqli_query($ahk_conn, "INSERT INTO `wallethistory`(`userid`, `amount`, `balance`, `purpose`, `status`, `type`) 
                VALUES ('$username','$fee','$debit_fee','Ration 2 UID Find','1','Debit')");
            ?>
            <script>
                $(function(){
                    Swal.fire(
                        'Found Successfully',
                        'Status: <?= $resdata['statusMessage'] ?? 'Success' ?>!',
                        'success'
                    )
                });
                setTimeout(() => {
                    window.location='#';
                }, 12000);
            </script>
            <?php
        }
    } else {
        ?>
        <script>
            $(function(){
                Swal.fire(
                    'Oops',
                    'Wallet Balance Insufficient! Please Recharge',
                    'error'
                )
            });
            window.setTimeout(function(){
                window.location.href='wallet.php';
            }, 10000);
        </script>
        <?php
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ration to UID</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SweetAlert & Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="page-wrapper">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">

                <div class="col-md-6">
                    <div class="card card-default">
                        <div class="card-header bg-warning">
                            <h3><strong>RATION TO AADHAAR FIND INSTANT (Uttar Pradesh)</strong></h3>
                        </div>
                    </div>

                    <div class="card col-12">
                        <hr>
                        <form action="" method="post">
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="rationNumber">Ration Number <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="rationNumber" id="rationNumber" placeholder="Enter Ration Number" required>
                                </div>
                                <h5 class="text-warning mt-2">Application Fee: ₹<?= $price['price']; ?></h5>
                                <div class="mt-3">
                                    <button type="submit" class="btn btn-primary w-100"><i class="fa fa-check-circle"></i> Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- UID Table -->
                <div class="col-md-12 mt-4">
                    <?php if (isset($resdata) && $resdata['success']) : ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead class="table-dark text-center">
                                    <tr>
                                        <th>UID No</th>
                                        <th>Name</th>
                                        <th>Father Name</th>
                                        <th>Gender</th>
                                        <th>DOB</th>
                                        <th>Relation</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if (!empty($resdata['result']['members'])) :
                                        foreach ($resdata['result']['members'] as $member): ?>
                                            <tr class="text-center">
                                                <td><?= $member['UIDNo']; ?></td>
                                                <td><?= $member['Nameof_Family_Member_EN']; ?></td>
                                                <td><?= $member['Father_Name_EN']; ?></td>
                                                <td><?= $member['Gender']; ?></td>
                                                <td><?= $member['DOB']; ?></td>
                                                <td><?= $member['RELATION']; ?></td>
                                            </tr>
                                        <?php endforeach;
                                    else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center">
                                                <button class="btn btn-danger"><b>NOT FOUND</b></button>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
<script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<script src="../template/ahkweb/assets/js/app.js"></script>

</body>
</html>

<?php include('../template/ahkweb/footer.php'); ?>

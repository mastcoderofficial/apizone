<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/header.php');

if (isset($_POST['rationNumber'])) {
    $rationNumber = trim($_POST['rationNumber']);

    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='ration2_uid_findfee'"));
    $fee = $price['price'];
    $username = $udata['phone'];
    $wallet = $udata['balance'];

    if ($wallet >= $fee) {
        $debit_fee = $wallet - $fee;
        $api_zone = "API_KEY_PASTE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )
        $url = "https://kycapizone.in/api/v2/ration/ration_to_uid.php?api_key=$api_zone&ration_no=$rationNumber";

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CUSTOMREQUEST => 'GET',
        ]);

        $response = curl_exec($curl);
        curl_close($curl);
        $resdata = json_decode($response, true);

        if ($resdata['success'] && $resdata['response_code'] === '100') {
            mysqli_query($ahk_conn, "UPDATE users SET balance='$debit_fee' WHERE phone='$username'");
            mysqli_query($ahk_conn, "INSERT INTO wallethistory(userid, amount, balance, purpose, status, type) VALUES ('$username','$fee','$debit_fee','Ration to UID Lookup','1','Debit')");

            echo "<script>Swal.fire('Success','UIDs found successfully.','success')</script>";
        } else {
            echo "<script>Swal.fire('Error','" . $resdata['response_message'] . "','error')</script>";
        }
    } else {
        echo "<script>Swal.fire('Low Balance','Please recharge your wallet.','warning'); setTimeout(() => window.location.href='wallet.php', 3000);</script>";
    }
}
?>

<div class="page-wrapper">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-5">
                    <div class="card shadow p-3">
                        <h4 class="text-warning">Ration ➜ Aadhaar Finder (U.P. only)</h4>
                        <form method="POST">
                            <div class="form-group mb-2">
                                <label>Ration Number</label>
                                <input type="text" name="rationNumber" class="form-control" placeholder="Enter Ration Number" required>
                            </div>
                            <div class="mb-2">
                                <label>Fee:</label>
                                <strong class="text-danger">&#8377; <?= $fee ?></strong>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Submit</button>
                        </form>
                    </div>
                </div>

                <?php if (isset($resdata['result']['members'])): ?>
                <div class="col-md-7">
                    <div class="card shadow p-3">
                        <h5 class="text-success">UID Details for Ration: <?= htmlspecialchars($resdata['result']['ration_no']) ?></h5>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Sr. No</th>
                                        <th>Name</th>
                                        <th>Father's Name</th>
                                        <th>Gender</th>
                                        <th>DOB</th>
                                        <th>Relation</th>
                                        <th>UID</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($resdata['result']['members'] as $member): ?>
                                        <tr>
                                            <td><?= $member['srno'] ?></td>
                                            <td><?= htmlspecialchars($member['Nameof_Family_Member_EN']) ?></td>
                                            <td><?= htmlspecialchars($member['Father_Name_EN']) ?></td>
                                            <td><?= htmlspecialchars($member['Gender']) ?></td>
                                            <td><?= htmlspecialchars($member['DOB']) ?></td>
                                            <td><?= htmlspecialchars($member['RELATION']) ?></td>
                                            <td><?= htmlspecialchars($member['UIDNo']) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

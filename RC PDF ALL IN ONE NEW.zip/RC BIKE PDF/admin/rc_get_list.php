<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/rc_get_list.php');

?>

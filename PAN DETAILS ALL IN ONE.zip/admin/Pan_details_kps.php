<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/Pan_details_kps.php');

?>

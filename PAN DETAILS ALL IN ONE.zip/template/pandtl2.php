<?php
include('header.php');

// Check if PAN is submitted
if (isset($_POST['verify_pan'])) {
    $pan_no = $_POST['pan_no'];
    
    $api_key = "api_key_paste";   // api buy from https://apizone.co.in

    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='pan_no' "));
    $fee = $price['price'];
    $username = $udata['phone'];
    $wallet_amount = $udata['balance'];

    // Check wallet balance
    if ($wallet_amount < $fee) {
        ?>
        <script>
            $(function() {
                Swal.fire(
                    'Insufficient Balance',
                    'Your wallet balance is too low to process this request',
                    'error'
                );
            });
            setTimeout(() => {
                window.location.href = 'wallet.php';
            }, 2000);
        </script>
        <?php
    } else {
        // API Request
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://kycapizone.in/api/v2/pan_advance/Panplus.php?api_key=$api_key&pan_no=$pan_no",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        $json = json_decode($response, true);

        if ($err || $json['status_code'] == 404) {
            // Deduct fee from the wallet for failed transaction
            $debit_fee = $wallet_amount - $fee;
            $debit = mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$username'");
            $updatehistory = mysqli_query($ahk_conn, "INSERT INTO `wallethistory`(`userid`, `amount`, `balance`, `purpose`, `status`, `type`) VALUES ('$username','$fee','$debit_fee','PAN Details Verify Failed','1','Debit')");

            ?>
            <script>
                $(function() {
                    Swal.fire(
                        'Verification Failed',
                        'The provided PAN number is invalid or data not found. Payment has been deducted and is non-refundable.',
                        'error'
                    );
                });
            </script>
            <?php
        } else {
            $status = $json['status'];
            $message = $json['message'];
            $code = $json['status_code'];

            if ($status == '100') {
                $data_result = $json['data_result'];
                $pan_number = $data_result['PAN'];
                $first_name = $data_result['FIRST_NAME'];
                $last_name = $data_result['LAST_NAME'];
                $father_name = $data_result['FATHER_NAME'];
                $aadhaar_number = $data_result['AADHAR_NUM'];
                $aadhaar_linked_status = $data_result['AADHAR_LINKED'] ? 'Linked' : 'Not Linked';
                $dob_verified = $data_result['DOB_VERIFIED'] ? 'Yes' : 'No';
                $dob = $data_result['DOB'];
                $gender = $data_result['GENDER'];
                $address = $data_result['FULL_ADDRESS'];

                date_default_timezone_set("Asia/Kolkata");
                $time_hkb = date('d/m/Y g:i:s');

                // Deduct fee from the wallet
                $debit_fee = $wallet_amount - $fee;
                $debit = mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$username'");

                $query = mysqli_query($ahk_conn, "INSERT INTO `pan_verify_hkb`(`name`, `fathername`, `gender`, `dob`, `pan`, `username`,`date`) VALUES ('$first_name $last_name','$father_name','$gender','$dob','$pan_number','$username','$time_hkb')");
                $updatehistory = mysqli_query($ahk_conn, "INSERT INTO `wallethistory`(`userid`, `amount`, `balance`, `purpose`, `status`, `type`) VALUES ('$username','$fee','$debit_fee','PAN Details Verify','1','Debit')");

                // Send message logic
                $data = [
                    'api_key' => $senurlkey,
                    'sender' => $sendurlsender,
                    'number' => "91$username",
                    'message' => "🔍PAN DETAILS FETCH Request is successful! \n 👤 User: $username \n Pan: $pan_number \n Name: *$first_name $last_name* \n Fathername: $father_name \n Gender: $gender \n Dob: $dob \n Aadhaar Status: $aadhaar_linked_status \n DOB Verified: $dob_verified \n 🙏 Thank you for using *SERVICE 4 PAN*!\n \n *ALL UPDATE JOIN GROUP:* https://chat.whatsapp.com/KBogmWHCncwJPKyZW3LGZ1"
                ];
                
                curl_close($curl);
            }
        }
    }
}
?>




<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
			
        <div class="main">
          <div class="col-lg-12">
                                         <div class="card" style="margin-left: 10px;    padding-left: 30px;
                                        padding-top: 12px;
                                      box-shadow: 1px 5px 5px 5px;">
                                 <div class="stat-widget-two">
                            <div class="stat-content">
                        <div class="stat-text">
                            <div class="container-fluid">
                              
                                <div class="row">
                                    <div class="col-lg-4 col-md-6 col-sm-6">
                                        <div class="card">
                                            <div class="card-body">
                            <div class="alert alert-danger" role="alert">
                                We Are Trying Our Best
                                                <a href="#" class="alert-link">Pan Details Print By Only....</a>
                                            </div>
                                            <hr>
                                            <form name="" action="" method="post" id="pan_verification">
                                                <div class="card-body">
                                                    <div class="col-md-10">
                                                        <div class="form-group">
                                                            <label class="form-group" for="pan_no">Enter PAN Number</label>
                                                        </div>
                                                        <input type="text" required="" class="form-control" name="pan_no" id="pan_no" placeholder="ENTER PAN NUMBER">
                                                    </div>
                                                </div>
                                                <div class="btn btn-outline-primary">
                                                    <h5 class="text-success">Application Fee: <?php  
                                                        $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT price FROM pricing WHERE service_name='pan_no'"));  
                                                        echo "₹ " . $price['price'];
                                                    ?></h5>
                                                </div>
                                                <div class="row row-sm mg-t-20">
                                                    <div class="col-lg">
                                                        <br>
                                                        <button type="submit" name="verify_pan" class="btn btn-success btn-block"><i class="fa fa-check-circle"></i> Verify PAN</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-8 col-md-6 col-sm-6">
                                    <div class="card" style="height: 380px; background-color: #c7f0d8;">
                                        <div class="card-body">
                                            <h6>Please pay attention. PAN card number and PAN card details are obtained. Remember, we are providing these services only for verification and not for misuse. Thanks.....</h6>
                                            <hr>
                                            <h6>Pan Number: <?php echo isset($pan_number) ? $pan_number : ''; ?></h6>
                                            <h6>Name: <?php echo isset($first_name) && isset($last_name) ? "$first_name $last_name" : ''; ?></h6>
                                            <h6>Father Name: <?php echo isset($father_name) ? $father_name : ''; ?></h6>
                                            <h6>Gender: <?php echo isset($gender) ? $gender : ''; ?></h6>
                                            <h6>Date of Birth: <?php echo isset($dob) ? $dob : ''; ?></h6>
                                            <h6>Address: <?php echo isset($address) ? $address : ''; ?></h6>
                                            <h6>Masked Aadhaar: <?php echo isset($aadhaar_number) ? $aadhaar_number : ''; ?></h6>
                                            <h6>Aadhaar Linked Status: <?php echo isset($aadhaar_linked_status) ? $aadhaar_linked_status : ''; ?></h6>
                                            <h6>DOB Verified: <?php echo isset($dob_verified) ? $dob_verified : ''; ?></h6>
                                            <br>
                                           
                                            <hr>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add your footer content here -->

    <script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
    <script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
    <script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
    <script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
    <script src="../template/ahkweb/assets/js/app.js"></script>
</body>
<script>
    function captureAndDownload() {
        // Specify the target element for capture
        var targetElement = document.getElementById('image_pr');

        // Use html2canvas to capture the content of the target element
        html2canvas(targetElement).then(function (canvas) {
            // Convert the canvas to a data URL
            var imageDataUrl = canvas.toDataURL('image/jpeg');

            // Create a link element for downloading the image
            var downloadLink = document.createElement('a');
            downloadLink.href = imageDataUrl;
            downloadLink.download = 'Hkb_pan_image.jpg'; // Set the desired filename

            // Trigger a click event on the link to start the download
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        });
    }
</script>
</html>

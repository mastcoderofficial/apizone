<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<?php
include('header.php');

if (isset($_POST['B2']) && $_POST['B2'] == "Bittu") {
     $rasan_no = mysqli_real_escape_string($ahk_conn,$_POST['rasan_no']);
     $state = mysqli_real_escape_string($ahk_conn,$_POST['state']);
     $area =mysqli_real_escape_string($ahk_conn,$_POST['area']);
     $district =mysqli_real_escape_string($ahk_conn,$_POST['district']);
     $application_no = "KPS_".rand(000000,999999);
     
     $price = mysqli_fetch_assoc(mysqli_query($ahk_conn,"SELECT * FROM pricing WHERE service_name='ration_pdf_hkb_print_fee' "));
     $fee = $price['price'];
     $username = $udata['phone'];
     $wallet_amount=$udata['balance'];
    
     if($wallet_amount > $fee){
    $debit_fee =  $wallet_amount - $fee;
    $api_hkb ="API_KEY_PASTE"; // Buy APi From This Website https://apizone.online ( Design & Development By KPS )
$url = "https://apizone.online/api/v2/ration/ration.php?state=$state&rasan_no=$rasan_no&area=$area&district=$district&api_key=$api_hkb";

$curl = curl_init();
curl_setopt_array($curl, array( 
  CURLOPT_URL => $url,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
));

 $response = curl_exec($curl);
 curl_close($curl);
// Execute cURL session
$resdata = json_decode($response, true);
// Check for cURL errors
$front=$resdata['front'];
$back=$resdata['back'];
$a4=$resdata['a4'];

if (curl_errno($ch)) {
     echo "cURL Error: " . curl_error($ch);

} else if($resdata['detail']){
    // Output API response
    ?>
    <script>
            $(function(){
                Swal.fire(
                    '<?php echo $resdata['detail']; ?>',
                    'Sorry',
                    'error'
                )
            });
            window.setTimeout(function(){
                window.location.href='Ration_Pdf_hkb.php';
            },2000);
            
        </script>
        <?php
   
}else if($resdata['error']){
    ?>
     <script>
            $(function(){
                Swal.fire(
                    '<?php echo $resdata['error']; ?>',
                    'Admin Token Error Contact ADMIN',
                    'warning'
                )
            });
            window.setTimeout(function(){
                window.location.href='Ration_Pdf_hkb.php';
            },20000);
            
        </script>
        <?php
}else if($front == ""){
    ?>
     <script>
            $(function(){
                Swal.fire(
                    ' <?php echo $response; ?>',
                    'Server Down , Please Try After Sometime',
                    'warning'
                )
            });
            window.setTimeout(function(){
                window.location.href='Ration_Pdf_hkb.php';
            },20000);
            
        </script>
        <?php
}else{
        $debit = mysqli_query($ahk_conn,"UPDATE users SET balance='$debit_fee' WHERE phone='$username'"); 
     if($debit){
      $insert = mysqli_query($ahk_conn, "INSERT INTO rasn_print (application_no,username,rasan_no,state,response,status, fee,front,back,pdf) VALUES ('$application_no','$username','$rasan_no', '$state', '$response','success', '$fee', '$front','$back','$a4');");
       
      
      if($insert){
          ?>
           <script>
                        $(function(){
                            Swal.fire(
                                'Rasan NO : <?php echo $rasan_no;?> is Downloaded',
                                'Application : <?php echo $application_no; ?> Message : File Generated',
                                'success'
                            )
                        })
                        setTimeout(() => {
                            window.location='Ration_Pdf_hkb_list.php';
                        }, 12000);
                    </script>
          <?php
      }
     }
    //  echo "API Response: " . $response;
}

// Close cURL session
curl_close($ch);

            
    }else{
        ?>
        <script>
            $(function(){
                Swal.fire(
                    'Opps',
                    'Wallet Balance Insufficient ! Please Recharge ',
                    'error'
                )
            });
            window.setTimeout(function(){
                window.location.href='wallet.php';
            },);
            
        </script>
        <?php
    }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="https://jeremyfagis.github.io/dropify/dist/css/dropify.min.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
</head>
<body>
    
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">DOWNLOAD RATION PDF </div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">New APPLY</li>
							</ol>
						</nav> 
					</div>
					<div class="ms-auto">
						<div class="btn-group"> 
							<button type="button" class="btn btn-primary">Settings</button>
							<button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">	<span class="visually-hidden">Toggle Dropdown</span>
							</button>
							<div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end">	<a class="dropdown-item" href="javascript:;">Action</a>
								<a class="dropdown-item" href="javascript:;">Another action</a>
								<a class="dropdown-item" href="javascript:;">Something else here</a>
								<div class="dropdown-divider"></div>	<a class="dropdown-item" href="javascript:;">Separated link</a>
							</div>
						</div>
					</div>
				</div>
				<!--end breadcrumb-->
				<div class="row">
					<div class="col-xl-10 mx-auto">
						<h6 class="mb-0 text-uppercase">RATION PDF PRINT</h6>
						<hr/>
						<div class="card border-top border-0 border-4 border-primary">
							<div class="card-body p-5">
								<div class="card-title d-flex align-items-center">
									<div><i class="bx bxs-id-card me-1 font-22 text-primary"></i>
									</div>
									<h5 class="mb-0 text-primary">Enter RATION Number Details</h5>
								</div>
								<hr>
 <div class="content-wrap">
    <div class="main">
        <div class="col-md-12">
            <div class="main-content">
                <section class="section">
                    <div class="section-header">
                        <div class="container-fluid">
                            <!--<div class="row">-->
                            <!--    <h1>Information <?php echo $wallet; ?></h1>-->
                            <!--</div>-->
                        </div>
                    </div>
                    <!--<div class="page-wrapper" style="display: block;">-->
                    <!--    <div class="page-breadcrumb">-->
                    <!--        <div class="row mb-2">-->
                    <!--            <div class="col-sm-6">-->
                    <!--                <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Instant Dl Print</h4>-->
                    <!--            </div>-->
                    <!--            <div class="col-sm-6 text-right">-->
                    <!--                <a href="dlprint_list" class="btn btn-primary btn-sm">Pan List</a>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                        <div class="col-md-12">
                            <div class="card card-default">
                                <div class="card-header bg-warning">
                                    <div class="card-title">
                                        <h3><strong>Enter beneficiary Details</strong></h3>
                                        <h4>Disclaimer :- CHARGE - ₹ 20, FAST SERVICE</h4>
                                        <h4>Disclaimer :- All state Is now Live ...</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="container-fluid">
                            <div class="card col-12">
                                <hr>
                                <div class="row">
                                    <div class="col-lg-4 col-md-6 col-sm-6">
                                        <div class="card">
                                            <div class="card-body">
                            <div class="alert alert-danger" role="alert">
                                We Are Trying Our Best
                                <a href="#" class="alert-link">RATION CARD IS NOW LIVE </a>
                            </div>
                            <form name="" action="" method="post" id="rasan_print">
                                <div class="card-body">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="card-title" for="state">State<span class="required-mark text-red" style="color:red;">*</span></label>
                                            <input type="hidden" name="B2" value="Bittu">
                                            <select name="state" id="state" required="" class="form-control">
                                                <option value="0">-Select State-</option>
                                                <option value="other">ALL STATE</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div id="areaRuralField" style="display: none;">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="card-title" for="area">Area / Rural<span class="required-mark text-red" style="color:red;">*</span></label>
                                                <select name="area" id="area" required="" class="form-control">
                                                    <option value="rbRural">Rural</option>
                                                    <option value="rbUrban">Urban</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="districtField" style="display: none;">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="card-title" for="district">District<span class="required-mark text-red" style="color:red;">*</span></label>
                                                <select name="district" id="district" class="form-control">
                                            	<option value="0">-Select District-</option>
                                            	<option value="203">Pashchim Champaran(01)</option>
                                            	<option value="204">Purba Champaran(02)</option>
                                            	<option value="205">Sheohar(03)</option>
                                            	<option value="206">Sitamarhi(04)</option>
                                            	<option value="207">Madhubani(05)</option>
                                            	<option value="208">Supaul(06)</option>
                                            	<option value="209">Araria(07)</option>
                                            	<option value="210">Kishanganj(08)</option>
                                            	<option value="211">Purnia(09)</option>
                                            	<option value="212">Katihar(10)</option>
                                            	<option value="213">Madhepura(11)</option>
                                            	<option value="214">Saharsa(12)</option>
                                            	<option value="215">Darbhanga(13)</option>
                                            	<option value="216">Muzaffarpur(14)</option>
                                            	<option value="217">Gopalganj(15)</option>
                                            	<option value="218">Siwan(16)</option>
                                            	<option value="219">Saran(17)</option>
                                            	<option value="220">Vaishali(18)</option>
                                            	<option value="221">Samastipur(19)</option>
                                            	<option value="222">Begusarai(20)</option>
                                            	<option value="223">Khagaria(21)</option>
                                            	<option value="224">Bhagalpur(22)</option>
                                            	<option value="225">Banka(23)</option>
                                            	<option value="226">Munger(24)</option>
                                            	<option value="227">Lakhisarai(25)</option>
                                            	<option value="228">Sheikhpura(26)</option>
                                            	<option value="229">Nalanda(27)</option>
                                            	<option value="230">Patna(28)</option>
                                            	<option value="231">Bhojpur(29)</option>
                                            	<option value="232">Buxar(30)</option>
                                            	<option value="233">Kaimur (Bhabua)(31)</option>
                                            	<option value="234">Rohtas(32)</option>
                                            	<option value="235">Jehanabad(37)</option>
                                            	<option value="236">Arwal(38)</option>
                                            	<option value="237">Aurangabad(33)</option>
                                            	<option value="238">Gaya(34)</option>
                                            	<option value="239">Nawada(35)</option>
                                            	<option value="240">Jamui(36)</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="rasanNoField" style="display: none;">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="card-title" for="rasan_no">Rasan Number</label>
                                                <input type="text" required="" class="form-control" name="rasan_no" id="rasan_no" placeholder="Enter Rasan Number">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        <div class="row row-sm mg-t-20">
                            <div class="col-lg">
                                <label class="ckbox mg-b-5">
                                    <input data-parsley-class-handler="#cbWrapper"
                                        data-parsley-errors-container="#cbErrorContainer" data-parsley-mincheck="2"
                                        name="browser[]" required="" type="checkbox" value="1"
                                        data-parsley-multiple="browser">
                                    <span>Terms & Conditions</span>
                                </label>
                            </div>
                        </div>
							<div class="row row-sm mg-t-20">
							<div class="col">
								<button type="submit" name="find" class="btn btn-primary w-100"><i class="fa fa-check-circle"></i> Submit</button>
							</div>
						</div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- JavaScript to show/hide form fields based on selected state -->
    <script>
        const stateDropdown = document.getElementById('state');
        const areaRuralField = document.getElementById('areaRuralField');
        const districtField = document.getElementById('districtField');
        const rasanNoField = document.getElementById('rasanNoField');

        stateDropdown.addEventListener('change', function () {
            const selectedState = stateDropdown.value;

            if (selectedState === 'BR') {
                areaRuralField.style.display = 'block';
                districtField.style.display = 'block';
                rasanNoField.style.display = 'block';
            } else {
                areaRuralField.style.display = 'none';
                districtField.style.display = 'none';
                rasanNoField.style.display = 'block'; // You may adjust this based on your requirements for other states.
            }
        });
    </script>
<!--end page wrapper -->
<?php 
include('footer.php');
?>
<!-- Bootstrap JS -->
<script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
<!--plugins-->
<script src="../template/ahkweb/assets/js/jquery.min.js"></script>
<script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<script src="../template/ahkweb/assets/plugins/chartjs/chart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/sparkline-charts/jquery.sparkline.min.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/excanvas.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/jquery.knob.js"></script>
<script>
$(function() {
    $(".knob").knob();
});
</script>
<script src="../template/ahkweb/assets/js/index.js"></script>
<!--app JS-->
<script src="../template/ahkweb/assets/js/app.js"></script>
<!-- datatable -->
<script src="../template/ahkweb/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="../template/ahkweb/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	
	<script>
		$(document).ready(function() {
			var table = $('#example2').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'pdf', 'print']
			} );
		 
			table.buttons().container()
				.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
		} );
	</script>
	
</body>



</html>
<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/Job_Card_kps.php');

?>

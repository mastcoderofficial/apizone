<?php
include('header.php');
?>
<?php

if (isset($_POST['check']) && $_POST['check'] == "aadhaar") {
    $aadhaar_check = $_POST['aadhaar_no'];
    $url = file_get_contents("https://apizone.online/api/verification/aadhaar_verify.php?aadhaar_no=$aadhaar_check");
    $result = json_decode($url, true);

    if ($result['status'] === 'success') {
        if ($result['code'] === '200') {
            // Success - Aadhaar is linked
            echo '<script>
                $(function(){
                    Swal.fire(
                        "We Found Linked Data",
                        "' . $result['message'] . '",
                        "success"
                    )
                })
            </script>';
        } else if ($result['code'] === '422') {
            // Aadhaar is not linked
            echo '<script>
                $(function(){
                    Swal.fire(
                        "Aadhaar Not Linked To Any Pan.",
                        "' . $result['message'] . '",
                        "error"
                    )
                })
            </script>';
        } else if ($result['code'] === '404') {
            // Invalid Aadhaar number
            echo '<script>
                $(function(){
                    Swal.fire(
                        "Please Enter Valid Aadhaar No.",
                        "' . $result['message'] . '",
                        "warning"
                    )
                })
            </script>';
        }
    } else {
        // Server error
        echo '<script>
            $(function(){
                Swal.fire(
                    "' . $result['status'] . '",
                    "SERVER DOWN PLEASE TRY AFTER SOMETIME",
                    "error"
                )
            })
        </script>';
    }
}
?>
<?php
if($result['code'] === '200'){
if($_POST['aadhaar_no']){
    $aadhaar = mysqli_real_escape_string($ahk_conn,$_POST['aadhaar_no']);
    $message= $result['message'];
    $username = $udata['phone'];
    $appliedby= $udata['phone'];
    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn,"SELECT * FROM pricing WHERE service_name='pan_no' "));
    $debit_fee =  $wallet_amount - $fee;
    if($udata['balance']>=$price['price']){
        $api_hkb ="API_KEY_PASTE"; // Buy APi From This Website https://apizone.online ( Design & Development By KPS )
        $url = 'https://apizone.online/api/panno/instant/aadhaar_to_pan.php?api_key='.$api_hkb.'&aadhaar_no='.$aadhaar;
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                ));
                $response = curl_exec($curl);
                curl_close($curl);
                    $response;
                $resdata = json_decode($response,true); 
                $pan=$resdata['pan_no'];
                $clint=$resdata['client_id'];
                $message_code=$resdata['status_code'];
                $message=$resdata['message'];
                $errore=$resdata['error'];
         if($errore){
                ?>
                 <script>
                      $(function(){
                         Swal.fire(
                            '<?php echo $errore;?>',
                                'Contact Admin',
                                'error'
                         )
                     })
                      setTimeout(() => {
                            window.location='';
                        }, 5000);
                    </script>
                <?php
            } else if($resdata['status']==="100"){
            $fee = $price['price'];
        $debit = mysqli_query($ahk_conn,"UPDATE users SET balance=balance-$fee WHERE phone='$appliedby'");
        $updatehistory = mysqli_query($ahk_conn,"INSERT INTO `wallethistory`(`userid`, `amount`, `balance`, `purpose`, `status`, `type`) VALUES ('$appliedby','$fee','$nbal','PAN Number Find','1','Debit')");
        if($debit){
            $insert = mysqli_query($ahk_conn, "INSERT INTO instantpan_find (application_no,username,aadhaar_no,pan_no,clint_id, status,status_code,fee,old_balance,new_balance,message) VALUES ('$application_no','$username','$aadhaar', '$pan', '$clint', '$message_code', '$response','" . $udata['pan_no_fee']. "','$wallet_amount','$debit_fee', '$message');");
            if($insert){
                ?>
                 <script>
                      $(function(){
                         Swal.fire(
                            'Pan No for <?php echo $aadhaar;?> is <?php echo $pan;?>',
                                '<?php echo $application_no; ?> Message : <?php echo $message; ?>',
                                'success'
                         )
                     })
                      setTimeout(() => {
                            window.location='';
                        }, 5000);
                    </script>
                <?php
            }else{
                ?>
                 <script>
          $(function(){
             Swal.fire(
                 'Balance Debited but data not insert',
                 'DATA INSERT ERROR',
                 'warning'
             )
         })
         setTimeout(() => {
                window.location='';
            }, 1200);
        </script>
                <?php
            }
        }else{
            ?>
              <script>
          $(function(){
             Swal.fire(
                 'Balance Debit error',
                 'something went wrong',
                 'error'
             )
         })
         setTimeout(() => {
                window.location='';
            }, 1200);
        </script>
            
            <?php
        }
            
        }else{
            ?>
            <script>
          $(function(){
             Swal.fire(
                            'Pan No for <?php echo $aadhaar;?> is <?php echo $pan;?>',
                                '<?php echo $application_no; ?> Message : <?php echo $message; ?>',
                 'warning'
             )
         })
         
        </script>
            
            <?php
        }
        
    }else{
        ?>
        <script>
          $(function(){
             Swal.fire(
                 'Wallet Balance is Low!',
                 'Please Recharge Now!',
                 'error'
             )
         })
         setTimeout(() => {
                window.location='wallet.php';
            }, 1200);
        </script>
      <?php  
    }
                       
                       
                   }
            }
            ?>
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Search PAN No</div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">New APPLY</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<button type="button" class="btn btn-primary">Settings</button>
							<button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">	<span class="visually-hidden">Toggle Dropdown</span>
							</button>
							<div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end">	<a class="dropdown-item" href="javascript:;">Action</a>
								<a class="dropdown-item" href="javascript:;">Another action</a>
								<a class="dropdown-item" href="javascript:;">Something else here</a>
								<div class="dropdown-divider"></div>	<a class="dropdown-item" href="javascript:;">Separated link</a>
							</div>
						</div>
					</div>
				</div>
				<!--end breadcrumb-->
				<div class="row">
					<div class="col-xl-10 mx-auto">
						<h6 class="mb-0 text-uppercase">INSTNAT PAN NO FIND SERVICE
						<hr/>
						<div class="card border-top border-0 border-4 border-primary">
							<div class="card-body p-5">
								<div class="card-title d-flex align-items-center">
									<div><i class="bx bxs-id-card me-1 font-22 text-primary"></i>
									</div>
									<h5 class="mb-0 text-primary">Enter AADHAAR NO TO GET INSTANT PAN NO</h5>
								</div>
								<hr>
								<form action="" method="POST" class="row g-3">
									
									<div class="col-md-3">
										<label for="inputLastName" class="form-label">AADHAAR No</label>
										<input name="aadhaar_no" type="text" id="aadhaar_no" placeholder="Enter 12 Digit AADHAAR  no" class="form-control" >
										       <input type="hidden" name="check" value="aadhaar">
									</div>
									
									
								
									
									
									<div class="col-12 ml-2">
									<h5 class="text-warning ">Application Fee: <?php  
										$price = mysqli_fetch_assoc(mysqli_query($ahk_conn,"SELECT price FROM pricing WHERE service_name='pan_no'")); 
										echo "₹" .$price['price'];
										?></h5>
										
									</div>
									<div class="col-12">
										<button type="submit" class="btn btn-primary px-5">Verify Now</button>
									</div>
                                       <!-- Result Section -->
                                              <?php if ($resdata['pan_no'] != '') { ?>
                                              <div class="col-lg-4 col-md-6 col-sm-6">
                                                  <div class="result-container" id="image_pr">
                                                       <div class="alert alert-success" role="alert">
                                                           Pan NO: <?php echo $resdata['pan_no']; ?><br>
                                                           Name: <?php echo $resdata['data_result']['name']; ?><br>
                                                           Father's Name: <?php echo $resdata['data_result']['father_name']; ?><br>
                                                           Gender: <?php echo $resdata['data_result']['gender']; ?><br>
                                                           Date of Birth: <?php echo $resdata['data_result']['dob']; ?><br><br>
                                                       </div>
                                                   </div>
                                              </div>
                                  <?php } ?>
								</form>
							</div>
						</div>
					

					</div>
				</div>
				
			</div>
		</div>
		
		<!--end page wrapper -->
		<?php 
		include('footer.php');
		?>
	<!-- Bootstrap JS -->
	

	<script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
	<!--plugins-->
	<!-- <script src="../template/ahkweb/assets/js/jquery.min.js"></script> -->
	<script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!--app JS-->
	<script src="../template/ahkweb/assets/js/app.js"></script>
</body>

<script>
	$(document).ready(function() {
	
	$('#eid').inputmask();
	$('#date').inputmask();
	$('#timea').inputmask("hh:mm:ss", {
        placeholder: "00:00:00", 
        insertMode: false, 
        showMaskOnHover: false,
        hourFormat: 12
      });
	});
</script>
</html>
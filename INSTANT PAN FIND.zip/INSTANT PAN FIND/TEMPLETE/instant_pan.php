<?php
include('header.php');
?>

<?php
if (isset($_POST['check']) && $_POST['check'] == "aadhaar") {
    $aadhaar_check = $_POST['aadhaar_no'];
    $url = file_get_contents("https://kycapizone.in/api/verification/aadhaar_verify.php?aadhaar_no=$aadhaar_check");
    $result = json_decode($url, true);

    if ($result['status'] === 'success') {
        if ($result['code'] === '200') {
            echo '<script>
                $(function(){
                    Swal.fire(
                        "We Found Linked Data",
                        "' . $result['message'] . '",
                        "success"
                    )
                })
            </script>';
        } elseif ($result['code'] === '422') {
            echo '<script>
                $(function(){
                    Swal.fire(
                        "Aadhaar Not Linked To Any PAN.",
                        "' . $result['message'] . '",
                        "error"
                    )
                })
            </script>';
        } elseif ($result['code'] === '404') {
            echo '<script>
                $(function(){
                    Swal.fire(
                        "Please Enter Valid Aadhaar No.",
                        "' . $result['message'] . '",
                        "warning"
                    )
                })
            </script>';
        }
    } else {
        echo '<script>
            $(function(){
                Swal.fire(
                    "Server Error",
                    "SERVER DOWN PLEASE TRY AFTER SOMETIME",
                    "error"
                )
            })
        </script>';
    }
}
?>

<?php
if (isset($_POST['aadhaar_no']) && $result['code'] === '200') {
    $aadhaar = mysqli_real_escape_string($ahk_conn, $_POST['aadhaar_no']);
    $username = $udata['phone'];
    $appliedby = $udata['phone'];
    $wallet_amount = $udata['balance'];
    $nbal = $wallet_amount; // Placeholder; update with actual logic if needed

    $priceData = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='pan_no'"));
    $fee = $priceData['price'];
    $debit_fee = $wallet_amount - $fee;

    if ($wallet_amount >= $fee) {
        $api_zone = "API_KEY_PASTE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )
        $url = "https://kycapizone.in/api/panno/instant/aadhaar_to_pan.php?api_key={$api_zone}&aadhaar_no={$aadhaar}";

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
        ));
        $response = curl_exec($curl);
        curl_close($curl);

        $resdata = json_decode($response, true);

        if (!$resdata['success']) {
            ?>
            <script>
                $(function () {
                    Swal.fire(
                        'API Error',
                        '<?= $resdata['message'] ?? "Unknown error" ?>',
                        'error'
                    )
                })
                setTimeout(() => {
                    window.location = '';
                }, 5000);
            </script>
            <?php
            exit;
        }

        if ($resdata['status'] === "100") {
            $pan = $resdata['result']['pan_no'];
            $application_no = $resdata['result']['application_no'];
            $clint = $resdata['result']['client_id'];
            $message = $resdata['message'];

            $debit = mysqli_query($ahk_conn, "UPDATE users SET balance = balance - $fee WHERE phone = '$appliedby'");
            $updatehistory = mysqli_query($ahk_conn, "INSERT INTO `wallethistory`(`userid`, `amount`, `balance`, `purpose`, `status`, `type`) VALUES ('$appliedby','$fee','$nbal','PAN Number Find','1','Debit')");

            if ($debit) {
                $insert = mysqli_query($ahk_conn, "INSERT INTO instantpan_find (application_no, username, aadhaar_no, pan_no, clint_id, status, status_code, fee, old_balance, new_balance, message) VALUES ('$application_no', '$username', '$aadhaar', '$pan', '$clint', '{$resdata['status']}', '{$resdata['status']}', '{$udata['pan_no_fee']}', '$wallet_amount', '$debit_fee', '$message')");

                if ($insert) {
                    ?>
                    <script>
                        $(function () {
                            Swal.fire(
                                'PAN Number Retrieved',
                                'Aadhaar: <?= $aadhaar ?>, PAN: <?= $pan ?>',
                                'success'
                            )
                        })
                        setTimeout(() => {
                            window.location = '';
                        }, 5000);
                    </script>
                    <?php
                } else {
                    ?>
                    <script>
                        $(function () {
                            Swal.fire(
                                'Insert Error',
                                'Balance debited but data insert failed.',
                                'warning'
                            )
                        })
                        setTimeout(() => {
                            window.location = '';
                        }, 1200);
                    </script>
                    <?php
                }
            } else {
                ?>
                <script>
                    $(function () {
                        Swal.fire(
                            'Balance Debit Failed',
                            'Something went wrong while debiting wallet.',
                            'error'
                        )
                    })
                    setTimeout(() => {
                        window.location = '';
                    }, 1200);
                </script>
                <?php
            }
        } else {
            ?>
            <script>
                $(function () {
                    Swal.fire(
                        'PAN Not Found',
                        '<?= $resdata['message'] ?>',
                        'warning'
                    )
                })
            </script>
            <?php
        }
    } else {
        ?>
        <script>
            $(function () {
                Swal.fire(
                    'Low Balance',
                    'Please recharge your wallet.',
                    'error'
                )
            })
            setTimeout(() => {
                window.location = 'wallet.php';
            }, 1200);
        </script>
        <?php
    }
}
?>

	<div class="page-wrapper">
    <div class="page-content">

        <!-- Breadcrumb -->
        <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
            <div class="breadcrumb-title pe-3">Search PAN No</div>
            <div class="ps-3">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0 p-0">
                        <li class="breadcrumb-item"><a href="#"><i class="bx bx-home-alt"></i></a></li>
                        <li class="breadcrumb-item active" aria-current="page">New Apply</li>
                    </ol>
                </nav>
            </div>
            <div class="ms-auto">
                <div class="btn-group">
                    <button type="button" class="btn btn-primary">Settings</button>
                    <button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">
                        <span class="visually-hidden">Toggle Dropdown</span>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end">
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <a class="dropdown-item" href="#">Something else here</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">Separated link</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- End breadcrumb -->

        <div class="row">
            <div class="col-xl-10 mx-auto">
                <h6 class="mb-0 text-uppercase">Instant PAN Number Find Service</h6>
                <hr/>
                <div class="card border-top border-0 border-4 border-primary">
                    <div class="card-body p-5">
                        <div class="card-title d-flex align-items-center mb-3">
                            <i class="bx bxs-id-card me-2 font-22 text-primary"></i>
                            <h5 class="mb-0 text-primary">Enter Aadhaar Number to Get Instant PAN Number</h5>
                        </div>

                        <form action="" method="POST" class="row g-3">
                            <div class="col-md-4">
                                <label for="aadhaar_no" class="form-label">Aadhaar Number</label>
                                <input name="aadhaar_no" type="text" id="aadhaar_no" placeholder="Enter 12-digit Aadhaar Number" class="form-control" required maxlength="12" pattern="\d{12}">
                                <input type="hidden" name="check" value="aadhaar">
                            </div>

                            <div class="col-12">
                                <h5 class="text-warning">Application Fee: 
                                    ₹<?php  
                                        $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT price FROM pricing WHERE service_name='pan_no'")); 
                                        echo $price['price'];
                                    ?>
                                </h5>
                            </div>

                            <div class="col-12">
                                <button type="submit" class="btn btn-primary px-5">Verify Now</button>
                            </div>

                            <?php if (!empty($resdata['result']['pan_no'])): ?>
                            <div class="col-lg-6 mt-4">
                                <div class="alert alert-success" role="alert">
                                    <h6 class="text-success">PAN Details Found</h6>
                                    <strong>PAN No:</strong> <?= htmlspecialchars($resdata['result']['pan_no']) ?><br>
                                    <strong>Application No:</strong> <?= htmlspecialchars($resdata['result']['application_no']) ?><br>
                                    <strong>Client ID:</strong> <?= htmlspecialchars($resdata['result']['client_id']) ?><br>
                                    <strong>Message:</strong> <?= htmlspecialchars($resdata['message']) ?><br>
                                </div>
                            </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>

<?php include('footer.php'); ?>

<!-- Scripts -->
<script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
<script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<script src="../template/ahkweb/assets/js/app.js"></script>

<script>
    $(document).ready(function () {
        $('#aadhaar_no').on('input', function () {
            this.value = this.value.replace(/[^0-9]/g, '').slice(0, 12);
        });
    });
</script>

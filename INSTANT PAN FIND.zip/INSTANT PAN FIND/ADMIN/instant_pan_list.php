
<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/instant_pan_list.php');

?>
<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/header.php');

// Fetch Fee
$price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='DBT_Agriculture_Fee'"));
$fee = $price['price'];
$resdata = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['app_no'])) {
    $app_no = trim($_POST['app_no']);
    $appliedby = $udata['phone'];
    $debit_fee = $udata['balance'] - $fee;

    if ($udata['balance'] >= $fee) {
        $api_zone = "API_KEY_PASTE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )
        $url = "https://kycapizone.in/api/v2/Aadhar_Advance/dbt_agriculture.php?api_key=$api_zone&app_no=$app_no";

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CUSTOMREQUEST => 'GET',
        ));
        $response = curl_exec($curl);
        curl_close($curl);

        $apiResult = json_decode($response, true);

        if ($apiResult && $apiResult['success'] === true && $apiResult['response_code'] === '100') {
            $resdata = $apiResult['result'];

            // Wallet debit
            mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$appliedby'");
            mysqli_query($ahk_conn, "INSERT INTO wallethistory(userid, amount, balance, purpose, status, type) VALUES ('$appliedby', '$fee', '$debit_fee', 'DBT Agriculture PDF', '1', 'Debit')");
        } else {
            echo "<script>Swal.fire('Failed', 'API Error: " . htmlspecialchars($apiResult['response_message'] ?? 'Unknown error') . "', 'error');</script>";
        }
    } else {
        echo "<script>Swal.fire('Low Balance', 'Please recharge your wallet!', 'warning');</script>";
    }
}
?>

<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
    <div class="row">
      <!-- Left Panel -->
      <div class="col-md-4">
        <form method="POST" class="card p-3 shadow">
          <h5 class="mb-3 text-danger">DBT Agriculture PDF</h5>
          <div class="form-group mb-2">
            <label>Application Number</label>
            <input type="text" name="app_no" required class="form-control" placeholder="Enter Application No.">
          </div>
          <div class="form-group mb-3">
            <label>Fee</label>
            <input type="text" class="form-control" value="₹ <?php echo $fee; ?>" readonly>
          </div>
          <button type="submit" class="btn btn-success w-100"><i class="fa fa-search"></i> Submit</button>
        </form>
      </div>

      <!-- Right Panel -->
      <?php if (!empty($resdata)): ?>
      <div class="col-md-8">
        <div class="card p-3 shadow">
          <h5>✅ DBT Record Found</h5>
          <table class="table table-bordered table-striped">
            <tr><th>Application No</th><td><?= htmlspecialchars($resdata['application_no'] ?? '-') ?></td></tr>
            <tr><th>Name</th><td><?= htmlspecialchars($resdata['name'] ?? '-') ?></td></tr>
            <tr><th>Download PDF</th>
              <td>
                <?php
                  $pdfData = $resdata['pdf'];
                  $cleanName = preg_replace('/[^a-zA-Z0-9]/', '_', $resdata['name']);
                  $filename = $cleanName . '_' . $resdata['application_no'] . '.pdf';

                  if (strpos($pdfData, 'base64,') !== false) {
                      $base64 = explode('base64,', $pdfData)[1];
                      $filePath = "./../uploads/dbt_pdfs/$filename";
                      file_put_contents($filePath, base64_decode($base64));
                      echo "<a href='$filePath' download='$filename' class='btn btn-primary btn-sm'>Download PDF</a>";
                  } else {
                      echo "Invalid PDF format.";
                  }
                ?>
              </td>
            </tr>
          </table>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include('footer.php'); ?>


 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<?php
include('header.php');
include('../../includes/config.php');


if (isset($_POST['b2']) && $_POST['b2'] == "Bittu") {
    
    $dl = mysqli_real_escape_string($ahk_conn,$_POST['dl']);
    $dob = mysqli_real_escape_string($ahk_conn,$_POST['dob']);
    $background = mysqli_real_escape_string($ahk_conn,$_POST['background']);
    $card_type = mysqli_real_escape_string($ahk_conn,$_POST['card_type']);
    $application_no = "KPS_".rand(000000,999999);
    if($card_type=="N"){
        $type="1";
    }else if($card_type=="C"){
        $type="2";
    }else{
         $type="1";
    }
    
    if($background=="B"){
        $color="true";
    }else if($background=="W"){
         $color="false";
    }else{
         $color="false";
    }
  $price = mysqli_fetch_assoc(mysqli_query($ahk_conn,"SELECT * FROM pricing WHERE service_name='dl_gf_instant' "));
    $fee = $price['price'];
    $username = $udata['phone'];
    $wallet=$udata['balance'];
            
            
    if($wallet > $fee){
    $debit_fee =  $wallet - $fee;
    $api_key ="Api_key_here";   //Api key Buy From Https://apizone.online
      // API endpoint
$url = "https://apizone.online/api/v2/dl/dl_verify.php?api_key=$api_key&dl=$dl&dob=$dob&color=$color&type=$type";

$curl = curl_init();
curl_setopt_array($curl, array( 
  CURLOPT_URL => $url,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
));

 $response = curl_exec($curl);
 curl_close($curl);

$resdata = json_decode($response, true);
// Check for cURL errors
$front=$resdata['front'];
$back=$resdata['back'];
$a4=$resdata['a4'];
if (curl_errno($ch)) {
     echo "cURL Error: " . curl_error($ch);

} else if($resdata['detail']){
    // Output API response
    ?>
    <script>
            $(function(){
                Swal.fire(
                    '<?php echo $resdata['detail']; ?>',
                    'Sorry',
                    'error'
                )
            });
            window.setTimeout(function(){
                window.location.href='DL_Instant_kps.php';
            },20000);
            
        </script>
        <?php
   
}else if($resdata['error']){
    ?>
     <script>
            $(function(){
                Swal.fire(
                    'Aurth Token Not Found :<?php echo $resdata['error']; ?>',
                    'Admin Token Error Contact : ',
                    'warning'
                )
            });
            window.setTimeout(function(){
                window.location.href='DL_Instant_kps.php';
            },20000);
            
        </script>
        <?php
}else if($resdata['a4'] ==''){
    
    ?>
     <script>
            $(function(){
                Swal.fire(
                    '<?php echo $response; ?>',
                    'Please Contact Admin : ',
                    'error'
                )
            });
            window.setTimeout(function(){
                window.location.href='DL_Instant_kps.php';
            },200000);
            
        </script>
        <?php
}else{
     $debit = mysqli_query($ahk_conn,"UPDATE `users` SET balance='$debit_fee' WHERE phone='$username'");
     if($debit){
      $insert = mysqli_query($ahk_conn, "INSERT INTO dlprint (application_no,username,dl_no,dob,response,status, fee,front,back,pdf) VALUES ('$application_no','$username','$dl', '$dob', '$response','success', '$fee', '$front','$back','$a4');");
      
           if($insert){
          ?>
           <script>
                        $(function(){
                            Swal.fire(
                                'Dl : <?php echo $dl;?> is Downloaded',
                                'Application : <?php echo $application_no; ?> Message : File Generated?>',
                                'success'
                            )
                        })
                        setTimeout(() => {
                            window.location='DL_Instant_kps_list.php';
                        }, 1200);
                    </script>
          <?php
      }
     
     }
    //  echo "API Response: " . $response;
}

// Close cURL session
curl_close($ch);

           
    }else{
        ?>
        <script>
            $(function(){
                Swal.fire(
                    'Opps',
                    'Wallet Balance Insufficient ! Please Recharge ',
                    'error'
                )
            });
            window.setTimeout(function(){
                window.location.href='wallet.php';
            },);
            
        </script>
        <?php
    }

}

?>

		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">FIND DL PDF </div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">New APPLY</li>
							</ol>
						</nav> 
					</div>
					<div class="ms-auto">
						<div class="btn-group"> 
							<button type="button" class="btn btn-primary">Settings</button>
							<button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">	<span class="visually-hidden">Toggle Dropdown</span>
							</button>
							<div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end">	<a class="dropdown-item" href="javascript:;">Action</a>
								<a class="dropdown-item" href="javascript:;">Another action</a>
								<a class="dropdown-item" href="javascript:;">Something else here</a>
								<div class="dropdown-divider"></div>	<a class="dropdown-item" href="javascript:;">Separated link</a>
							</div>
						</div>
					</div>
				</div>
				<!--end breadcrumb-->
				<div class="row">
					<div class="col-xl-10 mx-auto">
						<h6 class="mb-0 text-uppercase">DL PDF FIND</h6>
						<hr/>
						<div class="card border-top border-0 border-4 border-primary">
							<div class="card-body p-5">
								<div class="card-title d-flex align-items-center">
									<div><i class="bx bxs-id-card me-1 font-22 text-primary"></i>
									</div>
									<h5 class="mb-0 text-primary">Enter DL Number Details</h5>
								</div>
								<hr>
<div class="content-wrap">
    <div class="main">
        <div class="col-md-12">
            <div class="main-content">
                <!--<section class="section">-->
                    <div class="section-header">
                        <div class="container-fluid">
                            <!--<div class="row">-->
                            <!--    <h1>Information <?php echo $wallet; ?></h1>-->
                            <!--</div>-->
                        </div>
                    </div>
                    <!--<div class="page-wrapper" style="display: block;">-->
                    <!--    <div class="page-breadcrumb">-->
                    <!--        <div class="row mb-2">-->
                    <!--            <div class="col-sm-6">-->
                    <!--                <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Instant Dl Print</h4>-->
                    <!--            </div>-->
                    <!--            <div class="col-sm-6 text-right">-->
                    <!--                <a href="dlprint_list" class="btn btn-primary btn-sm">Pan List</a>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                        <div class="col-md-12">
                            <div class="card card-default">
                                <div class="card-header">
                                    <div class="card-title">
                                        <h3><strong>Enter beneficiary Details</strong></h3>
                                        <h4>Disclaimer :- CHARGE - ₹ <?php $price = mysqli_fetch_assoc(mysqli_query($ahk_conn,"SELECT * FROM pricing WHERE service_name='dl_gf_instant' ")); 
                                                                      echo $price['price']+3; ?>, FAST SERVICE</h4>
                                        <h4>Disclaimer :- Instant Service</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="container-fluid">
                            <div class="card col-12">
                                <hr>
                                <div class="row">
                                    <div class="col-lg-4 col-md-6 col-sm-6">
                                        <div class="card">
                                            <div class="card-body">
                                                <form name="" action="" method="post" id="dlprint">
                                                    <div class="card-body">
                                                        <div class="form-group">
                                                            <label class="card-title" for="dl">Dl Number</label>
                                                            <input type="text" class="form-control" name="dl" id="dl" placeholder="Enter Dl Number">
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="card-title" for="dob">D.O.B</label>
                                                            <input type="text" class="form-control" name="dob" id="dob" placeholder="Enter Dob">
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="card-title" for="background">Card Background<span class="required-mark text-red" style="color:red;">*</span></label>
                                                            <input type="hidden" name="b2" value="Bittu">
                                                            <select name="background" id="background" required="" class="form-control">
                                                                <option value="B">Blue</option>
                                                                <option value="W">White</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="card-title" for="card_type">Card Type<span class="required-mark text-red" style="color:red;">*</span></label>
                                                            <select name="card_type" id="card_type" required="" class="form-control">
                                                                <option value="C">Chip Pvc</option>
                                                                <option value="N">Normal Pvc</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-actions">
                                                            <div class="text-left">
                                                                <button type="submit" class="btn btn-info">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>

<!--end page wrapper -->
<?php 
include('footer.php');
?>
<!-- Bootstrap JS -->
<script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
<!--plugins-->
<script src="../template/ahkweb/assets/js/jquery.min.js"></script>
<script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<script src="../template/ahkweb/assets/plugins/chartjs/chart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/sparkline-charts/jquery.sparkline.min.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/excanvas.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/jquery.knob.js"></script>
<script>
$(function() {
    $(".knob").knob();
});
</script>
<script src="../template/ahkweb/assets/js/index.js"></script>
<!--app JS-->
<script src="../template/ahkweb/assets/js/app.js"></script>
<!-- datatable -->
<script src="../template/ahkweb/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="../template/ahkweb/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	
	<script>
		$(document).ready(function() {
			var table = $('#example2').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'pdf', 'print']
			} );
		 
			table.buttons().container()
				.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
		} );
	</script>
	
</body>



</html>
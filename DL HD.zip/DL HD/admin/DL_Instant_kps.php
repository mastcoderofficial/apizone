<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/DL_Instant_kps.php');

?>

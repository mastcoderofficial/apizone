<?php
include('header.php');

if (isset($_POST['find'])) {
    $rc_no = mysqli_real_escape_string($ahk_conn, $_POST['rc_dl']);

    $price_query = mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='rc_vehical_fee'");
    $price = mysqli_fetch_assoc($price_query);
    $fee = $price['price'];
    
    $username = $udata['phone'];
    $wallet_amount = $udata['balance'];
    $debit_fee = $wallet_amount - $fee;
    $api_hkb ="apikey_paste"; 
    if ($wallet_amount > $fee) {
        $url = "https://apizone.online/api/v2/vehical_rc/rc_verify.php?api_key=$api_hkb&rc_no=$rc_no";
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        $result = json_decode($response, true);

        if (isset($result['error'])) {
            ?>
            <script>
                $(function(){
                    Swal.fire(
                        '<?php echo $result['error']; ?>',
                        'Contact ADMIN',
                        'warning'
                    )
                });
                window.setTimeout(function(){
                    window.location.href='Rc_pdf.php';
                }, 20000);
            </script>
            <?php
        } else if (isset($result['rc_details']) && $result['rc_details']['statusCode'] == 200) {
            $statusMessage = $result['rc_details']['statusMessage'];
            $bik_number = $result['rc_details']['is_number'];
            $name = $result['rc_details']['name'];
            $fathername = $result['rc_details']['fathername'];
            $address = $result['rc_details']['address'];
            $file = $result['rc_details']['pdf'];

            $debit = mysqli_query($ahk_conn, "UPDATE users SET balance=balance-$fee WHERE phone='$username'");
            date_default_timezone_set("Asia/Kolkata");
            $time_hkb = date('d/m/Y g:i:s');

            $insert = mysqli_query($ahk_conn, "INSERT INTO `rc_vehical`(`username`, `rc_vehical_no`, `status`, `pdf`, `date`) VALUES ('$username', '$bik_number', '$statusMessage', '$file', '$time_hkb')");
            if (!$insert) {
                die('Error: ' . mysqli_error($ahk_conn));
            }
            $updatehistory = mysqli_query($ahk_conn, "INSERT INTO `wallethistory`(`userid`, `amount`, `balance`, `purpose`, `status`, `type`) VALUES ('$username', '$fee', '$debit_fee', 'RC Vehical PDF', '1', 'Debit')");

            if ($insert) {
                $legand_fetch = mysqli_fetch_array(mysqli_query($ahk_conn, "SELECT * FROM `users` WHERE `phone`='$username'"));
                $fullname = $legand_fetch['name'];

                $sender = "$sender_number";
                $number = 91 . $username;
                $usermsg = urlencode("Thank You 🎉 Dear *$fullname* 🎉 Your data *Rc PDF Print*

_Your Data Applicant Bik No : *$bik_number* ");

                $sms_url = "{$senurl}?api_key={$senurlkey}&sender={$sendurlsender}&number={$number}&message=$usermsg";
                $response2 = file_get_contents("$sms_url");
                ?>
                <script>
                    $(function(){
                        Swal.fire(
                            'Download Successfully, RC <?php echo $bik_number; ?>',
                            'Server : <?php echo $statusMessage; ?>!',
                            'success'
                        )
                    });
                    setTimeout(() => {
                        window.location='Rc_pdf_list.php';
                    }, 3000);
                </script>
                <?php
            }
        }
    } else {
        ?>
        <script>
            $(function(){
                Swal.fire(
                    'Opps',
                    'Wallet Balance Insufficient! Please Recharge',
                    'error'
                )
            });
            window.setTimeout(function(){
                window.location.href='wallet.php';
            }, 4000);
        </script>
        <?php
    }
}
?>



<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
			
<div class="content-wrap">
    <div class="main">
        <div class="col-md-12">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="alert alert-dark" role="alert">
                                    We Are Trying Our Best
                                    <a href="#" class="alert-link">RC BOOK / OWNER BOOK PDF DOWNLOAD </a>
                                </div>
                                 <form name="" action="" method="post" id="Job_print">
                                    <div class="card-body">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="card-title" for="rc_dl">Enter Vehicle Number</label>
                                                <input type="text" required="" class="form-control" name="rc_dl" id="rc_dl" placeholder="BH01XX1454"  oninput="removeSpaces(this)">
                                            </div>
                                        </div>
                                    </div>
                                    	<div class="col-12 ml-2">
									<h5 class="text-success ">Application Fee: <?php  
										$price = mysqli_fetch_assoc(mysqli_query($ahk_conn,"SELECT price FROM pricing WHERE service_name='rc_vehical_fee'")); 
										echo "₹ " .$price['price'];
										?></h5>
										<BR>
                                    
                                    <div class="row row-sm mg-t-20">
                                        <div class="col">
                                            <button type="submit" name="find" class="btn btn-success btn-block"><i class="fa fa-check-circle"></i> Submit</button>
                                        </div>
                                    </div>
					 </div>
                        </form>
                    </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function removeSpaces(inputElement) {
    inputElement.value = inputElement.value.replace(/\s/g, '');
}
</script>
<?php include("footer.php");?>
<!-- Bootstrap JS -->
<script src="../template/ahkweb/assets/js/bootstrap.bundle.min.js"></script>
<!--plugins-->
<script src="../template/ahkweb/assets/js/jquery.min.js"></script>
<script src="../template/ahkweb/assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="../template/ahkweb/assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="../template/ahkweb/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<script src="../template/ahkweb/assets/plugins/chartjs/chart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
<script src="../template/ahkweb/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
<script src="../template/ahkweb/assets/plugins/sparkline-charts/jquery.sparkline.min.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/excanvas.js"></script>
<script src="../template/ahkweb/assets/plugins/jquery-knob/jquery.knob.js"></script>
<script>
$(function() {
    $(".knob").knob();
});
</script>
<script src="../template/ahkweb/assets/js/index.js"></script>
<!--app JS-->
<script src="../template/ahkweb/assets/js/app.js"></script>
<!-- datatable -->
<script src="../template/ahkweb/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="../template/ahkweb/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	
	<script>
		$(document).ready(function() {
			var table = $('#example2').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'pdf', 'print']
			} );
		 
			table.buttons().container()
				.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
		} );
	</script>
	
</body>



</html>
<?php
include('../includes/session.php');
include('../includes/config.php');
include('../template/ahkweb/header.php');

if (isset($_POST['bikeNumber'])) {
    $bikeNumber = $_POST['bikeNumber'] ?? null;

    $price = mysqli_fetch_assoc(mysqli_query($ahk_conn, "SELECT * FROM pricing WHERE service_name='challan_fee'"));
    $fee = $price['price'];
    $username = $udata['phone'];
    $wallet = $udata['balance'];

    if ($wallet > $fee) {
        $debit_fee = $wallet - $fee;

        $api_zone ="APIKEYPASTEEEE"; // Buy APi From This Website https://apizone.co.in ( Design & Development By KPS )
        $url = "https://kycapizone.in/api/v2/dl/chalancheck.php?api_key=$api_zone&rc_number=$bikeNumber";

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
        ]);

        $response = curl_exec($curl);
        curl_close($curl);
        $resdata = json_decode($response, true);

        if (!$resdata['success']) {
            ?>
            <script>
                $(function(){
                    Swal.fire(
                        'API Error',
                        'Please Try After Sometime',
                        'warning'
                    )
                });
                window.setTimeout(function(){
                    window.location.href='#';
                }, 20000);
            </script>
            <?php
        } elseif ($resdata['success'] && $resdata['status'] == "200") {
            $debit = mysqli_query($ahk_conn, "UPDATE `users` SET balance='$debit_fee' WHERE phone='$username'");
            date_default_timezone_set('Asia/Kolkata');
            $timestamp = date("Y-m-d H:i:s");      
            $updatehistory = mysqli_query($ahk_conn,"INSERT INTO `wallethistory`(`userid`, `amount`, `balance`, `purpose`, `status`, `type`) VALUES ('$username','$fee','$debit_fee','Challan Details Find','1','Debit')");
            ?>
            <script>
                $(function(){
                    Swal.fire(
                        'Found Successfully',
                        'Status: <?= $resdata['message']; ?>',
                        'success'
                    )
                })
                setTimeout(() => {
                    window.location='#';
                }, 12000);
            </script>
            <?php
        } 
    } else {
        ?>
        <script>
            $(function(){
                Swal.fire(
                    'Oops',
                    'Wallet Balance Insufficient! Please Recharge',
                    'error'
                )
            });
            window.setTimeout(function(){
                window.location.href='wallet.php';
            }, 10000);
        </script>
        <?php
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="page-wrapper">
        <div class="page-content">
            <div class="main">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="main-content">
                                <div class="card card-default">
                                    <div class="card-header bg-warning">
                                        <div class="card-title">
                                            <h3><strong>CHALLAN FIND INSTANT</strong></h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="card col-12">
                                    <hr>
                                    <div class="row dgnform">
                                        <form action="" method="post" id="rasan_print">
                                            <div class="card-body">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="bikeNumber">Vehical Number <span class="text-red">*</span></label>
                                                        <input type="text" class="form-control" name="bikeNumber" id="bikeNumber" placeholder="Enter Vehicle Number">
                                                    </div>
                                                </div>
                                                <div class="col-12 ml-2">
                                                </div>
                                                <div class="row row-sm mg-t-20">
                                                    <div class="col">
                                                        <button type="submit" class="btn btn-primary w-100"><i class="fa fa-check-circle"></i> Submit</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php if (isset($resdata) && $resdata['success'] && $resdata['status'] == "200") : ?>
                            <div class="col-md-12">
                                <div class="table-responsive mt-4">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th class="text-center">RC Number</th>
                                                <th class="text-center">Accused Name</th>
                                                <th class="text-center">Challan No</th>
                                                <th class="text-center">Offense</th>
                                                <th class="text-center">Location</th>
                                                <th class="text-center">Date</th>
                                                <th class="text-center">Status</th>
                                                <th class="text-center">Fine Amount</th>
                                                <th class="text-center">Penalty</th>
                                                <th class="text-center">Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                            $challans = $resdata['result']['challan_details']['challans'];
                                            foreach ($challans as $challan):
                                            ?>
                                            <tr>
                                                <td><?= $challan['rc_number']; ?></td>
                                                <td><?= $challan['accused_name']; ?></td>
                                                <td><?= $challan['challan_number']; ?></td>
                                                <td><?= $challan['offense_details']; ?></td>
                                                <td><?= $challan['challan_place']; ?></td>
                                                <td><?= $challan['challan_date']; ?></td>
                                                <td>
                                                    <?php if (strtolower($challan['challan_status']) == 'paid'): ?>
                                                        <button class="btn btn-success">PAID</button>
                                                    <?php else: ?>
                                                        <button class="btn btn-danger">UNPAID</button>
                                                    <?php endif; ?>
                                                </td>
                                                <td>₹<?= $challan['amount']; ?></td>
                                                <td>₹<?= $challan['lk_fees']; ?></td>
                                                <td><strong>₹<?= $challan['total_amount']; ?></strong></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php include('footer.php'); ?>

